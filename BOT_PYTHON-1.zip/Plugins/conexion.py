import sqlite3
import time

def connect_to_db():
    conn = sqlite3.connect('usuarios.db')
    return conn
