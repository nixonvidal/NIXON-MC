from pyrogram import Client, filters, InlineKeyboardButton, InlineKeyboardMarkup

# Comando /contact
@Client.on_message(filters.command("contact"))
def contact_command(client, message):
    contact_info = "Puedes contactar a @Nikobhyn en Telegram:"

    # Crear el botón de contacto
    contact_button = InlineKeyboardButton(
        text="Contactar", url="https://t.me/Nikobhyn"
    )

    # Crear el teclado en línea con el botón de contacto
    reply_markup = InlineKeyboardMarkup([[contact_button]])

    # Enviar el mensaje con el botón
    message.reply_text(contact_info, reply_markup=reply_markup)

