import time
from datetime import datetime
from pyrogram import Client, filters
from pyrogram.types import Message
from Plugins.conexion import connect_to_db
from func_bin import get_bin_info
import subprocess
def verificar_usuario(telegram_id):
    conn = connect_to_db()
    c = conn.cursor()
    c.execute("SELECT * FROM usuarios WHERE telegram_id=?", (telegram_id,))
    result = c.fetchone() is not None
    conn.close()
    return result

def calcular_dias_restantes(fecha_registro, dias):
    tiempo_actual = datetime.now().timestamp()
    segundos_restantes = (fecha_registro.timestamp() + (dias * 24 * 60 * 60)) - tiempo_actual
    dias_restantes = segundos_restantes / (24 * 60 * 60)
    return dias_restantes
#------COMANDO CAMBIAR PASSWORD VPS ROOT--------#
@Client.on_message(filters.command("pass", prefixes=['.','/','!'], case_sensitive=False) & filters.text)
def pass_command(client, message):
    telegram_id = message.from_user.id
    if verificar_usuario(telegram_id):
        conn = connect_to_db()
        c = conn.cursor()
        c.execute("SELECT dias, rango, fecha_registro FROM usuarios WHERE telegram_id=?", (telegram_id,))
        usuario_info = c.fetchone()
        dias_registrado = usuario_info[0]
        rango = usuario_info[1]
        fecha = usuario_info[2]

        fecha_registro = datetime.strptime(fecha, '%Y-%m-%d')
        dias_restantes = calcular_dias_restantes(fecha_registro, dias_registrado)
        dias_restantes = int(dias_restantes)

        if dias_restantes <= 0:
            message.reply_text("❌NO TIENES PERMISO...")
        else:
            if len(message.command) != 4:
                message.reply_text("/ssh IP USER PASS NEW_PASS")
                return
            ip = message.command[1]
            usuario = message.command[2]
            password = message.command[3]
            new_password = message.command[4]
            script_bash = f'''
            #!/bin/bash
            ip="{ip}"
            user="{usuario}"
            pass="{password}"
            new_password="{new_password}"
            TOKEN="5232741342:AAHyeF16tQ7IT11VvFFdkMeQB-2pEJ7XOME"
            ID="{telegram_id}"
            URL="https://api.telegram.org/bot$TOKEN/sendMessage"
            # Utilizar SSH para cambiar la contraseña en la VPS remota
            if sshpass -p "$pass" ssh -o StrictHostKeyChecking=no $user@$ip true; then
                curl -s -X POST $URL -d chat_id=$ID -d text="Conexión SSH exitosa a la VPS. ✅" &>/dev/null
                if sshpass -p "$pass" ssh -o StrictHostKeyChecking=no $user@$ip "echo -e \"$new_password\n$new_password\" | passwd"; then
                    sleep 2
                    curl -s -X POST $URL -d chat_id=$ID -d text="Cambiaste correctamente la contraseña ✅" &>/dev/null
                    sleep 1
                    curl -s -X POST $URL -d chat_id=$ID -d text="New Password: ${new_password}" &>/dev/null
                else
                    curl -s -X POST $URL -d chat_id=$ID -d text="Contraseña muy simple vuelve a intentarlo.. ❌" &>/dev/null
                fi
            else
                curl -s -X POST $URL -d chat_id=$ID -d text="ERROR -> conectar VPS ❌" &>/dev/null
            fi
            '''
            resultado = subprocess.run(['/bin/bash', '-c', script_bash], input='', text=True)
            print(resultado.stdout)
    else:
        message.reply_text("Para acceder a este comando, primero necesitas registrarte usando /register.")