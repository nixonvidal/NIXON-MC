from pyrogram import Client, filters

@Client.on_message(filters.command("id"))
def info_command(client, message):
    user = message.from_user
    chat_id = message.chat.id
    user_info = f"""
ℹ️ Información del Usuario:
👤 Nombre de usuario: <code>{user.username}</code>
🆔 ID del Usuario: <code>{user.id}</code>
👨 Nombre: <code>{user.first_name}</code>
🧔 Apellido: <code>{user.last_name if user.last_name else '-'}</code>
📱 Chat ID: <code>{chat_id}</code>
    """

    message.reply_text(user_info)
