import "./src/app.js";
