#!/bin/bash
gt="/etc/kevn" && [[ ! -d ${gt} ]] && mkdir ${gt}
SCPT_DIR="${gt}/gh"
mkdir -p ${SCPT_DIR}
DIR="/etc/http-shell"
LIST="CM-NOXIN"
BASICINST="menu message.txt usercodes C-SSR.sh squid.sh squid.sh dropbear.sh proxy.sh openvpn.sh ssl.sh python.py shadowsocks.sh Shadowsocks-libev.sh Shadowsocks-R.sh v2ray.sh slowdns.sh budp.sh sockspy.sh PDirect.py PPub.py PPriv.py POpen.py PGet.py ADMbot.sh apacheon.sh tcp.sh fai2ban.sh blockBT.sh ultrahost speed.py squidpass.sh ID extras.sh"

meu_ip() {
  MIP=$(ip addr | grep -o -E 'inet [0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | grep -v '127.' | awk '{print $2}' | head -1)
  MIP2=$(wget -qO- ipv4.icanhazip.com)
  IP="${MIP:-$MIP2}"
}

meu_ip

fun_list() {
    KEY="$1"
    mkdir -p ${DIR}/${KEY}
    i=0
    for arqx in $(ls ${SCPT_DIR} | grep -vE "${BASICINST// /|}"); do
        arq_list[$i]="${arqx}"
        let i++
    done
    arqslist="$BASICINST"
    for arqx in $(echo "${arqslist}"); do
        [[ -e ${DIR}/${KEY}/$arqx ]] && continue
        cp ${SCPT_DIR}/$arqx ${DIR}/${KEY}/
        echo "$arqx" >>${DIR}/${KEY}/${LIST}
    done
    echo "unnamed" >${DIR}/${KEY}.name
}

ofus() {
    server=$(echo ${txt_ofuscatw} | cut -d':' -f1)
    number=$(expr length $1)
    for ((i = 1; i < $number + 1; i++)); do
        txt[$i]=$(echo "$1" | cut -b $i)
        case ${txt[$i]} in
        ".") txt[$i]="F" ;;
        "F") txt[$i]="." ;;
        "3") txt[$i]="@" ;;
        "@") txt[$i]="3" ;;
        "5") txt[$i]="9" ;;
        "9") txt[$i]="5" ;;
        "6") txt[$i]="P" ;;
        "P") txt[$i]="6" ;;
        "L") txt[$i]="R" ;;
        "R") txt[$i]="L" ;;
        esac
        txtofus+="${txt[$i]}"
    done
    echo "$txtofus" | rev
}

valuekey="$(date | md5sum | head -c10)"
valuekey+="$(echo $(($RANDOM * 10)) | head -c 5)"
fun_list "$valuekey"
keyfinal=$(ofus "$IP:8888/$valuekey/$LIST")
echo $keyfinal