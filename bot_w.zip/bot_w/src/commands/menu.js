import { readFile } from "node:fs";

export default {
  name: "menu",
  description: "Lista de comandos o detalles de estos.",
  alias: ["m"],
  use: "/menu (comando)",

  run: (socket, msg, args) => {
    const name = args.join(" ");
    const { commands } = socket;
    const menuText = `
*———『BOT WHATSAPP』———*
*『𝐂𝐎𝐌𝐀𝐍𝐃𝐎𝐒 𝐁𝐀𝐒𝐈𝐂𝐎𝐒』*
▶︎ /ask ▶︎ /clima
▶︎ /facebook ▶︎ /instagram
▶︎ /lyrics ▶︎ /play ▶︎ /mp3
▶︎ /sticker ▶︎ /tiktok
▶︎ /tts ▶︎ /wikipedia
———————————————————
*『DESCARGA EHI Y APK』*
▶︎ /ehi
▶︎ /apk
*『𝐂𝐎𝐌𝐀𝐍𝐃𝐎𝐒 𝐃𝐄 𝐃𝐎𝐗𝐄𝐎』*
▶︎ /dni ▶︎ /nya
———————————————————
*『𝐂𝐎𝐌𝐀𝐍𝐃𝐎𝐒 𝐃𝐄 𝐂𝐀𝐑𝐃𝐈𝐍𝐆』*
▶︎ /bin ▶︎ /checker ▶︎ /extra
———————————————————
*『𝘽𝘼𝙎𝙃 𝙎𝙃𝙀𝙇𝙇』*
▶︎ /pass ▶︎ /keygen ▶︎ /ssh
*『𝐂𝐎𝐌𝐀𝐍𝐃𝐎𝐒 𝐃𝐄 𝐀𝐃𝐌𝐈𝐍』*
▶︎ /add ▶︎ /del
———————————————————
𝒐𝒘𝒏𝒆𝒓: https://wa.me/+51974312499
    `;

    if (!name) {
      try {
        // Enviar video
        socket.sendMessage(
          msg.messages[0].key.remoteJid,
          {
            image: {
              url: "https://raw.githubusercontent.com/nixonvidal/NIXON-MC/master/img/photo_2024-03-22_14-22-10.jpg",
            },
            caption: menuText,
          },
          { quoted: msg.messages[0] }
        );
      } catch (error) {
        console.error(error);
      }
      return;
    }

    const command = commands.find(
      (c) => c.name === name || c.alias.includes(name)
    );

    if (!command) {
      socket.sendMessage(msg.messages[0].key.remoteJid, {
        text: `No se encontró el comando ${name}.`,
      });
      return;
    }

    const info = `
*Información del comando: ${command.name}*
${command.description}

**Alias:** ${command.alias.join(", ") || "Sin alias"}
**Uso:** ${command.use}
      `;

    socket.sendMessage(msg.messages[0].key.remoteJid, {
      text: info,
    });
  },
};
