import ytdl from "@distube/ytdl-core"; // Asegúrate de que este sea el módulo correcto para descargar solo audio
import ytSearch from "yt-search";

export default {
  name: "mp3",
  description: "Descarga canciones de Youtube.",
  alias: ["p"],
  use: "!mp3 'nombre o url'",

  run: async (socket, msg, args) => {
    try {
      const query = args.join(" ");

      if (!query) {
        return socket.sendMessage(msg.messages[0].key.remoteJid, {
          text: "Ingresa el nombre o URL del audio.",
        });
      }

      socket.sendMessage(msg.messages[0]?.key.remoteJid, {
        react: { text: "⏳", key: msg.messages[0]?.key },
      });

      const video = (await ytSearch(query)).videos[0];

      if (!video) {
        await socket.sendMessage(msg.messages[0].key.remoteJid, {
          text: "Sin resultados disponibles.",
        });

        return socket.sendMessage(msg.messages[0]?.key.remoteJid, {
          react: { text: "❌", key: msg.messages[0]?.key },
        });
      }

      // Descargar solo el audio
      const stream = ytdl(video.url, {
        filter: "audioonly",
        quality: "highestaudio",
      });
      await socket.sendMessage(msg.messages[0].key.remoteJid, {
        image: { url: video.thumbnail || video.image },
        caption: `*${video.title}*\n\n*Autor:* ${video.author?.name}\n*Duración:* ${video.timestamp}\n*Vistas:* ${video.views}`,
      });
      
      await socket.sendMessage(msg.messages[0].key.remoteJid, {
        document: { stream },
        fileName: video.title + ".mp3",
        mimetype: "audio/mp3",
        caption: `Duración > ${video.timestamp}\nVistas > ${video.views}\nAutor > ${video.author.name}`,
      });

      socket.sendMessage(msg.messages[0]?.key.remoteJid, {
        react: { text: "✅", key: msg.messages[0]?.key },
      });
    } catch (error) {
      console.error(error);

      await socket.sendMessage(msg.messages[0].key.remoteJid, {
        text: "¡Ups! Acaba de suceder un error inesperado.",
      });

      socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
        react: { text: "❌", key: msg.messages[0]?.key },
      });
    }
  },
};
