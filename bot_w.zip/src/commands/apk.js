import axios from "axios";

export default {
  name: "apk",
  description: "Envía diferentes archivos APK desde URLs específicas.",
  alias: ["apk"],
  use: "/apk <Custom|inyector|nikobhyntools|clashmc|clashmeta|nedmod|nixonmcpro>",

  run: async (socket, msg, args) => {
    // Definir las URLs de los archivos
    const fileUrls = {
      custom: "https://github.com/nixonvidal/NIXON-MC/raw/master/bot_wa/aplicaciones/custom.apk",
      inyector: "https://github.com/nixonvidal/NIXON-MC/raw/master/bot_wa/aplicaciones/inyector.apk",
      nikobhyntools: "https://github.com/nixonvidal/NIXON-MC/raw/master/Nikobhyn%20Tools.apk",
      clashmc: "https://github.com/nixonvidal/NIXON-MC/raw/master/bot_wa/aplicaciones/clashmc.apk",
      clashmeta: "https://github.com/nixonvidal/NIXON-MC/raw/master/bot_wa/aplicaciones/clashmeta.apk",
      nedmod: "https://github.com/nixonvidal/NIXON-MC/raw/master/bot_wa/aplicaciones/nedmod.apk",
      nixonmcpro: "https://github.com/nixonvidal/NIXON-MC/raw/master/bot_wa/aplicaciones/nixonmcpro.apk",
    };

    // Verificar si se proporcionó el argumento correcto
    if (args.length < 1 || !fileUrls[args[0].toLowerCase()]) {
      // Enviar mensaje de error si el argumento no es válido
      await socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
        text: "Uso incorrecto del comando. Usa /apk <Custom|inyector|nikobhyntools|clashmc|clashmeta|nedmod|nixonmcpro>.",
      });
      return;
    }

    // Obtener la URL del archivo correspondiente
    const fileUrl = fileUrls[args[0].toLowerCase()];

    try {
      // Enviar mensaje de "Descargando..."
      await socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
        text: "Descargando archivo...",
      });

      // Descargar el archivo
      const response = await axios.get(fileUrl, {
        responseType: "stream",
      });

      // Enviar el archivo como documento
      await socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
        document: {
          stream: response.data,
        },
        fileName: `${args[0]}.apk`,
        mimetype: "application/vnd.android.package-archive",
      });

      // Enviar mensaje de éxito
      await socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
        text: "El archivo se ha enviado correctamente.",
      });
    } catch (error) {
      console.error(error);

      // Enviar mensaje de error
      await socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
        text: "¡Ups! Ha ocurrido un error al enviar el archivo.",
      });
    }
  },
};
