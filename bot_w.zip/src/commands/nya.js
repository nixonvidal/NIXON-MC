import axios from "axios";

export default {
  name: "nya",
  description: "Obtén el clima actual de tu ciudad o país.",
  alias: ["numero"],
  use: "!nya 'nombres|apellidoPaterno|apellidoMaterno'",

  run: async (socket, msg, args) => {
    const input = args.join(" "); // Unir los argumentos en una sola cadena
    const [nombres = "", apellidoPaterno = "", apellidoMaterno = ""] =
      input.split("|");
    // Mostrar los nombres y apellidos en la consola
    console.log("Nombres:", nombres);
    console.log("Apellido Paterno:", apellidoPaterno);
    console.log("Apellido Materno:", apellidoMaterno);

    if (!nombres || !apellidoPaterno || !apellidoMaterno) {
      socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
        text: `*/nya nombres|apellidoPaterno|apellidoMaterno*`,
      });
      return;
    }
    if (msg.messages[0]?.key?.remoteJid === "51974312499-1605450776@g.us") {
      socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
        text: `*Buscando..*`,
      });

      const apiUrl = `http://161.132.38.96/index.php?nya=${nombres}|${apellidoPaterno}|${apellidoMaterno}`;
      const auth = {
        username: "cat",
        password: "catpass",
      };

      try {
        const response = await axios.get(apiUrl, { auth });

        if (response.status !== 200) {
          throw new Error(`¡Error HTTP! Estado: ${response.status}`);
        }

        const data = response.data[0]; // Solo tomamos el primer objeto de la respuesta

        // Construir el mensaje con los datos formateados
        let message = `DNI: ${data.DNI}\n`;
        message += `Apellido Paterno: ${data.AP_PAT}\n`;
        message += `Apellido Materno: ${data.AP_MAT}\n`;
        message += `Nombres: ${data.NOMBRES}\n`;
        message += `Fecha de Nacimiento: ${data.FECHA_NAC}\n`;
        message += `Fecha de Inscripción: ${data.FCH_INSCRIPCION}\n`;
        //message += `Fecha de Emisión: ${data.FCH_EMISION}\n`;
        //message += `Fecha de Caducidad: ${data.FCH_CADUCIDAD}\n`;
        message += `Ubigeo de Nacimiento: ${data.UBIGEO_NAC}\n`;
        message += `Ubigeo de Dirección: ${data.UBIGEO_DIR}\n`;
        message += `Dirección: ${data.DIRECCION}\n`;
        message += `Sexo: ${data.SEXO === "1" ? "Masculino" : "Femenino"}\n`;
        message += `Estado Civil: ${data.EST_CIVIL.trim()}\n`;
        message += `Dígito RUC: ${data.DIG_RUC}\n`;
        message += `Madre: ${data.MADRE}\n`;
        message += `Padre: ${data.PADRE}\n`;

        // Enviar la respuesta al usuario a través del socket
        socket.sendMessage(
          msg.messages[0]?.key?.remoteJid,
          {
            text: message,
          },
          { quoted: msg.messages[0] }
        );
      } catch (error) {
        console.error(error);
        socket.sendMessage(
          msg.messages[0]?.key?.remoteJid,
          {
            text: `*Error al obtener la información.*`,
          },
          { quoted: msg.messages[0] }
        );
      }
    } else {
      socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
        text: "No tienes permiso para ejecutar este comando.",
      });
    }
  },
};
