import axios from "axios";
import { verificarRolUsuario } from "../conexion.js";

export default {
  name: "nya",
  description: "Obtén el clima actual de tu ciudad o país.",
  alias: ["nya"],
  use: "/nya 'nombres|apellidoPaterno|apellidoMaterno'",

  run: async (socket, msg, args) => {
    const input = args.join(" "); // Unir los argumentos en una sola cadena
    const [nombres = "", apellidoPaterno = "", apellidoMaterno = ""] =
      input.split("|");
    // Mostrar los nombres y apellidos en la consola
    console.log("Nombres:", nombres);
    console.log("Apellido Paterno:", apellidoPaterno);
    console.log("Apellido Materno:", apellidoMaterno);

    if (!nombres || !apellidoPaterno || !apellidoMaterno) {
      socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
        text: `*/nya nombres|apellidoPaterno|apellidoMaterno*`,
      });
      return;
    }

    const sender = msg.messages[0]?.key?.remoteJid;

    // Verificar el rol del usuario
    verificarRolUsuario(sender, async (err, rol) => {
      if (err) {
        console.error(err);
        socket.sendMessage(
          sender,
          {
            text: `*Error al verificar el rol del usuario.*`,
          },
          { quoted: msg.messages[0] }
        );
        return;
      }

      if (rol !== "usuario" && rol !== "admin") {
        socket.sendMessage(sender, {
          text: "No tienes permiso para ejecutar este comando.",
        });
        return;
      }

      socket.sendMessage(
        sender,
        {
          text: `*Buscando..*`,
        },
        { quoted: msg.messages[0] }
      );

      const apiUrl = `http://161.132.48.201/index.php?nya=${nombres}|${apellidoPaterno}|${apellidoMaterno}`;
      const auth = {
        username: "nixon",
        password: "nixon",
      };

      try {
        const response = await axios.get(apiUrl, { auth });

        if (response.status !== 200) {
          throw new Error(`¡Error HTTP! Estado: ${response.status}`);
        }

        const data = response.data[0]; // Solo tomamos el primer objeto de la respuesta

        // Construir el mensaje con los datos formateados
        const message = `
*———「BUSQUEDA POR NYA」———*
DNI: ${data.DNI}
Apellido Paterno: ${data.AP_PAT}
Apellido Materno: ${data.AP_MAT}
Nombres: ${data.NOMBRES}
Fecha de Nacimiento: ${data.FECHA_NAC}
Fecha de Inscripción: ${data.FCH_INSCRIPCION}
Ubigeo de Nacimiento: ${data.UBIGEO_NAC}
Ubigeo de Dirección: ${data.UBIGEO_DIR}
Dirección: ${data.DIRECCION}
Sexo: ${data.SEXO === "1" ? "Masculino" : "Femenino"}
Estado Civil: ${data.EST_CIVIL.trim()}
Dígito RUC: ${data.DIG_RUC}
Madre: ${data.MADRE}
Padre: ${data.PADRE}
—————————————————
                `;

        // Enviar la respuesta al usuario a través del socket
        socket.sendMessage(
          sender,
          { text: message },
          { quoted: msg.messages[0] }
        );
      } catch (error) {
        console.error(error);
        socket.sendMessage(
          sender,
          {
            text: `*Error al obtener la información.*`,
          },
          { quoted: msg.messages[0] }
        );
      }
    });
  },
};
