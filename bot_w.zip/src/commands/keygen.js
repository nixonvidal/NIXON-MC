import { exec } from "child_process";

export default {
  name: "keygen",
  description: "Genera una clave utilizando un script shell.",
  alias: ["keygen"],
  use: "!keygen",

  run: async (socket, msg, args) => {
    // Ruta al archivo .sh que genera la clave
    const rutaArchivoSh = "/ruta/al/archivo.sh"; // Cambia esto con la ruta real de tu archivo.sh
    if (msg.messages[0]?.key?.remoteJid === "51974312499@s.whatsapp.net") {
      // Ejecutar el archivo .sh para generar la clave
      exec(`sh ${rutaArchivoSh}`, (error, stdout, stderr) => {
        if (error) {
          console.error(`Error al ejecutar el archivo .sh: ${error.message}`);
          socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
            text: `Error al generar la clave. Por favor, inténtalo de nuevo más tarde.`,
          });
          return;
        }
        if (stderr) {
          console.error(
            `Error en la salida estándar del archivo .sh: ${stderr}`
          );
          socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
            text: `Error al generar la clave. Por favor, inténtalo de nuevo más tarde.`,
          });
          return;
        }
        console.log(`Salida estándar del archivo .sh: ${stdout}`);

        // Enviar la clave generada como respuesta al usuario a través del socket
        socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
          text: `Se ha generado la clave correctamente:\n${stdout}`,
        });
      });
    } else {
      socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
        text: "No tienes permiso para ejecutar este comando.",
      });
    }
  },
};
