import axios from "axios";
import { verificarRolUsuario } from "../usuarios.js";

export default {
  name: "dni",
  description: "Obtén el clima actual de tu ciudad o país.",
  alias: ["numero"],
  use: "!cliema 'ciudad o país'",

  run: async (socket, msg, args) => {
    const dni = args.join(" ");

    if (!dni) {
      socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
        text: `*/dni 71262578*`,
      });

      return;
    }

    const sender = msg.messages[0]?.key?.remoteJid;

    // Verificar el rol del usuario
    verificarRolUsuario(sender, async (err, rol) => {
      if (err) {
        console.error(err);
        socket.sendMessage(
          msg.messages[0]?.key?.remoteJid,
          {
            text: `*Error al verificar el rol del usuario.*`,
          },
          { quoted: msg.messages[0] }
        );
        return;
      }

      if (rol !== "usuario" && rol !== "admin") {
        socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
          text: "No tienes permiso para ejecutar este comando.",
        });
        return;
      }

      socket.sendMessage(
        msg.messages[0]?.key?.remoteJid,
        {
          text: `*Buscando..*`,
        },
        { quoted: msg.messages[0] }
      );

      const apiUrl = `http://161.132.38.96/index.php?dni=${dni}`;
      const auth = {
        username: "cat",
        password: "catpass",
      };

      try {
        const response = await axios.get(apiUrl, { auth });

        if (response.status !== 200) {
          throw new Error(`¡Error HTTP! Estado: ${response.status}`);
        }

        const data = response.data[0]; // Solo tomamos el primer objeto de la respuesta

        const message = `
*———「BUSQUEDA POR DNI」———*
DNI: ${data.DNI}
Apellido Paterno: ${data.AP_PAT}
Apellido Materno: ${data.AP_MAT}
Nombres: ${data.NOMBRES}
Fecha de Nacimiento: ${data.FECHA_NAC}
Fecha de Inscripción: ${data.FCH_INSCRIPCION}
Ubigeo de Nacimiento: ${data.UBIGEO_NAC}
Ubigeo de Dirección: ${data.UBIGEO_DIR}
Dirección: ${data.DIRECCION}
Sexo: ${data.SEXO === "1" ? "Masculino" : "Femenino"}
Estado Civil: ${data.EST_CIVIL.trim()}
Dígito RUC: ${data.DIG_RUC}
Madre: ${data.MADRE}
Padre: ${data.PADRE}
—————————————————
        `;

        // Enviar la respuesta al usuario a través del socket
        socket.sendMessage(
          msg.messages[0]?.key?.remoteJid,
          { text: message },
          { quoted: msg.messages[0] }
        );
      } catch (error) {
        console.error(error);
        socket.sendMessage(
          msg.messages[0]?.key?.remoteJid,
          {
            text: `*Error al obtener la información.*`,
          },
          { quoted: msg.messages[0] }
        );
      }
    });
  },
};
