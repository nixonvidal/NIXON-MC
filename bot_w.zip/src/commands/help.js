import { readFile } from "node:fs";

export default {
  name: "menu", // Cambiar el nombre del comando a "menu"
  description: "Lista de comandos o detalles de estos.", // Puedes dejar la descripción como está o ajustarla según lo necesites
  alias: ["m"], // Puedes definir un alias opcional para el comando
  use: "!menu (comando)", // Ajustar el uso del comando si es necesario

  run: (socket, msg, args) => {
    const name = args.join(" ");

    const command = socket.commands.find((c) => {
      return c.name === name || c.alias.includes(name);
    });

    if (!name || !command) {
      const commands = socket.commands.map((c) => c.name).join("\n");

      socket.sendMessage(msg.messages[0].key.remoteJid, {
        text: `*Mis comandos:*\n${commands}`,
      });

      return;
    }

    const info = `*Información del comando: ${command.name}*\n${
      command.description
    }\n\nAlias: ${command.alias.join(", ") || "Sin alias"}\n\nUso: ${
      command.use
    }\n\n'Obligatorio' (Opcional)`;

    socket.sendMessage(msg.messages[0].key.remoteJid, {
      text: info,
    });
  },
};
