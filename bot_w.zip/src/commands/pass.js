import { exec } from 'child_process';

export default {
  name: "pass",
  description: "Cambia la contraseña de una VPS.",
  alias: ["pass"],
  use: "!pass 'IP|USUARIO|CONTRASEÑA|NUEVA_CONTRASEÑA'",

  run: async (socket, msg, args) => {
    // Verificar si el mensaje proviene del usuario autorizado
    if (msg.messages[0]?.key?.remoteJid !== "51974312499@s.whatsapp.net") {
      socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
        text: "No tienes permiso para ejecutar este comando.",
      });
      return;
    }

    // Verificar si se proporcionaron los argumentos esperados
    if (args.length < 1) {
      socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
        text: "Faltan argumentos. Usa el comando de la forma: !pass 'IP|USUARIO|CONTRASEÑA|NUEVA_CONTRASEÑA'",
      });
      return;
    }

    const input = args.join(" "); // Unir los argumentos en una sola cadena
    const [ip, usuario, pass, newpass] = input.split("|");

    // Verificar si todos los argumentos necesarios están presentes
    if (!ip || !usuario || !pass || !newpass) {
      socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
        text: "Faltan argumentos. Usa el comando de la forma: !pass 'IP|USUARIO|CONTRASEÑA|NUEVA_CONTRASEÑA'",
      });
      return;
    }

    // Comando para cambiar la contraseña en la VPS
    const comando = `sshpass -p '${pass}' ssh -o StrictHostKeyChecking=no ${usuario}@${ip} 'echo -e "${newpass}\n${newpass}" | passwd'`;

    // Ejecutar el comando para cambiar la contraseña
    exec(comando, (error, stdout, stderr) => {
      if (error) {
        console.error(`Error al cambiar la contraseña: ${error.message}`);
        socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
          text: `Error al cambiar la contraseña en la VPS. Por favor, inténtalo de nuevo más tarde.`,
        });
        return;
      }

      const successMessage = 'passwd: password updated successfully';
      const warningMessage = 'Warning: Permanently added';

      // Verificar si la salida contiene el mensaje de éxito y la advertencia
      if (stderr.includes(successMessage) || stdout.includes(successMessage)) {
        if (stderr.includes(warningMessage) || stdout.includes(warningMessage)) {
          console.log(`Contraseña cambiada correctamente en la VPS con advertencias: ${stderr || stdout}`);
        } else {
          console.log(`Contraseña cambiada correctamente en la VPS: ${stdout}`);
        }
        socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
          text: `La contraseña se ha cambiado correctamente en la VPS.`,
        });
      } else {
        console.error(`Error en la salida estándar del comando: ${stderr}`);
        socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
          text: `Error al cambiar la contraseña en la VPS. Por favor, inténtalo de nuevo más tarde.`,
        });
      }
    });
  },
};
