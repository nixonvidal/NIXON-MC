import { exec } from "child_process";

export default {
  name: "ssh",
  description: "Instala un script en una VPS mediante SSH.",
  alias: ["ssh"],
  use: "!installScript 'ip|usuario|password'",

  run: async (socket, msg, args) => {
    const input = args.join(" "); // Unir los argumentos en una sola cadena
    const [ip = "", usuario = "", password = ""] = input.split("|");

    // Verificar si se proporcionaron los argumentos esperados
    if (!ip || !usuario || !password) {
      socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
        text: `Faltan argumentos. Usa el comando de la forma: !installScript 'ip|usuario|password'`,
      });
      return;
    }

    // Verificar si el mensaje proviene del usuario autorizado
    if (msg.messages[0]?.key?.remoteJid !== "51948415593@s.whatsapp.net") {
      socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
        text: "No tienes permiso para ejecutar este comando.",
      });
      return;
    }

    // Script de Bash a ejecutar en la VPS
    const script_bash = `
#!/bin/bash
ip="${ip}"
user="${usuario}"
pass="${password}"

if sshpass -p "$pass" ssh -o StrictHostKeyChecking=no $user@$ip true; then
    echo "Conexión SSH exitosa a la VPS. ✅"

    # Se instala script en la VPS
    echo "⏱️ COMENZANDO A INSTALAR SCRIPT..."
    sshpass -p "$pass" ssh $user@$ip <<EOF
wget https://raw.githubusercontent.com/nixonvidal/NIXON-MC/master/Install-Sin-Key.sh; chmod 777 Install-Sin-Key.sh; ./Install-Sin-Key.sh
rm -rf Install-Sin-Key.sh
echo "✅ INSTALACION COMPLETADA SCRIPT NIXON MC 9.9 ✅"
EOF
else
    echo "No se pudo conectar a la VPS mediante SSH. ❌"
fi
`;

    // Ejecutar el script en la VPS mediante SSH
    exec(
      `echo "${script_bash}" | sshpass -p "${password}" ssh ${usuario}@${ip}`,
      (error, stdout, stderr) => {
        if (error) {
          console.error(`Error al ejecutar el comando SSH: ${error.message}`);
          socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
            text: `Error al ejecutar el script en la VPS. Por favor, inténtalo de nuevo más tarde.`,
          });
          return;
        }
        if (stderr) {
          console.error(
            `Error en la salida estándar del comando SSH: ${stderr}`
          );
          socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
            text: `Error al ejecutar el script en la VPS. Por favor, inténtalo de nuevo más tarde.`,
          });
          return;
        }
        console.log(`Salida estándar del comando SSH: ${stdout}`);

        // Enviar la salida estándar del comando SSH como respuesta al usuario a través del socket
        socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
          text: `Se ha ejecutado el script en la VPS correctamente:\n${stdout}`,
        });
      }
    );
  },
};
