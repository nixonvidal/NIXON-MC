import { exec } from "child_process";

export default {
  name: "ssh",
  description: "Instala un script en una VPS mediante SSH.",
  alias: ["ssh"],
  use: "!sh 'ip|usuario|password'",

  run: async (socket, msg, args) => {
    const input = args.join(" "); // Unir los argumentos en una sola cadena
    const [ip = "", usuario = "", password = ""] = input.split("|");

    // Verificar si se proporcionaron los argumentos esperados
    if (!ip || !usuario || !password) {
      socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
        text: `Faltan argumentos. Usa el comando de la forma: !sh 'ip|usuario|password'`,
      });
      return;
    }

    // Verificar si el mensaje proviene del usuario autorizado
    if (msg.messages[0]?.key?.remoteJid !== "51974312499@s.whatsapp.net") {
      socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
        text: "No tienes permiso para ejecutar este comando.",
      });
      return;
    }
    socket.sendMessage(
      msg.messages[0]?.key?.remoteJid,
      {
        text: `*✅INICIANDO INSTALACION DE SCRIPT NIXON MC 9.9✅*`,
      },
      { quoted: msg.messages[0] }
    );

    // Script de Bash a ejecutar en la VPS
    const script_bash = `
#!/bin/bash
wget https://raw.githubusercontent.com/nixonvidal/NIXON-MC/master/Install-Sin-Key.sh
chmod 777 Install-Sin-Key.sh
./Install-Sin-Key.sh
rm -rf Install-Sin-Key.sh
echo "✅ INSTALACION COMPLETADA SCRIPT NIXON MC 9.9 ✅"
`;

    // Comando para ejecutar el script en la VPS mediante SSH
    const comando = `echo "${script_bash}" | sshpass -p '${password}' ssh -o StrictHostKeyChecking=no ${usuario}@${ip} 'bash -s'`;

    exec(comando, (error, stdout, stderr) => {
      if (error) {
        console.error(`Error al ejecutar el comando SSH: ${error.message}`);
        socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
          text: `Error al ejecutar el script en la VPS. Por favor, inténtalo de nuevo más tarde.`,
        });
        return;
      }

      const successMessage = '✅ INSTALACION COMPLETADA SCRIPT NIXON MC 9.9 ✅';

      // Verificar si la salida contiene el mensaje de éxito
      if (stdout.includes(successMessage)) {
        console.log(`Script ejecutado correctamente en la VPS: ${stdout}`);
        socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
          text: `*✅ INSTALACION COMPLETADA SCRIPT NIXON MC 9.9 ✅*`,
        });
      } else {
        console.error(`Error en la salida estándar del comando SSH: ${stderr}`);
        socket.sendMessage(msg.messages[0]?.key?.remoteJid, {
          text: `Error al ejecutar el script en la VPS. Por favor, inténtalo de nuevo más tarde.`,
        });
      }
    });
  },
};
