import connection from './conexion.js';

// Verificar el rol del usuario
export const verificarRolUsuario = (remotejid, callback) => {
  connection.query('SELECT rol FROM usuarios WHERE remotejid = ?', [remotejid], (err, results) => {
    if (err) {
      callback(err, null);
      return;
    }
    if (results.length === 0) {
      // El usuario no está en la base de datos, puedes manejar esto como desees
      callback(null, null); // Cambiado para devolver null si el usuario no está en la base de datos
      return;
    }
    callback(null, results[0].rol);
  });
};
