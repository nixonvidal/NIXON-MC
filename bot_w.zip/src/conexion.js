import mysql from 'mysql2';

// Crear una conexión a la base de datos
const connection = mysql.createConnection({
  host: 'localhost',       // La dirección del servidor de la base de datos
  user: 'root',      // Tu usuario de la base de datos
  password: '1234', // La contraseña de tu base de datos
  database: 'whatsapp_db' // El nombre de tu base de datos
});

// Conectar a la base de datos
connection.connect((err) => {
  if (err) {
    console.error('Error conectando a la base de datos:', err);
    return;
  }
  console.log('Conexión exitosa a la base de datos.');
});

// Exportar la conexión para usarla en otros módulos
export default connection;
