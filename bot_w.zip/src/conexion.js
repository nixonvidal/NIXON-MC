import mysql from 'mysql2';

let connection;

// Función para conectar a la base de datos
const connectToDatabase = () => {
  connection = mysql.createConnection({
    host: 'localhost',
    user: 'admin',
    password: 'cat123',
    database: 'whatsapp_db'
  });

  // Manejar eventos de error y reconexión
  connection.on('error', (err) => {
    console.error('Error en la conexión a la base de datos:', err);
    // Reconectar si la conexión se cierra inesperadamente
    if (err.code === 'PROTOCOL_CONNECTION_LOST') {
      connectToDatabase();
    } else {
      throw err;
    }
  });

  connection.connect((err) => {
    if (err) {
      console.error('Error conectando a la base de datos:', err);
      return;
    }
    console.log('Conexión exitosa a la base de datos.');
  });
};

connectToDatabase();

// Verificar el rol del usuario
export const verificarRolUsuario = (remotejid, callback) => {
  connection.query('SELECT rol FROM usuarios WHERE remotejid = ?', [remotejid], (err, results) => {
    if (err) {
      callback(err, null);
      return;
    }
    if (results.length === 0) {
      // El usuario no está en la base de datos, puedes manejar esto como desees
      callback(null, null); // Cambiado para devolver null si el usuario no está en la base de datos
      return;
    }
    callback(null, results[0].rol);
  });
};

// Exportar la conexión para usarla en otros módulos
export { connection };
