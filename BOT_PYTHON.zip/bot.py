import os  # Librería para interactuar con el sistema operativo
import logging  # Librería para configurar logs
from pyrogram import Client  # Librería Pyrogram para crear un cliente de Telegram
from dotenv import load_dotenv  # Librería para cargar variables de entorno desde un archivo .env

# Carga las variables de entorno desde el archivo .env
config = load_dotenv(".env")

# Crear un cliente de Pyrogram para el bot
Anonymous = Client(
    "bot_bins",  # Nombre del cliente
    api_id=os.getenv('API_ID'),  # ID de API obtenido desde las variables de entorno
    api_hash=os.getenv('API_HASH'),  # Hash de la API obtenido desde las variables de entorno
    bot_token=os.getenv('BOT_TOKEN'),  # Token del bot obtenido desde las variables de entorno
    plugins=dict(root='Plugins')  # Directorio de los plugins del bot
)

# Manejador para las consultas de callback
@Anonymous.on_callback_query()
def callback_privates(client, callback_query):
    # Obtener el mensaje al que se está respondiendo
    reply_message = callback_query.message.reply_to_message
    # Verificar si hay un mensaje y si el usuario que lo envió no es el mismo que está haciendo la consulta
    if reply_message is not None and reply_message.from_user is not None:
        if reply_message.from_user.id != callback_query.from_user.id:
            # Enviar un mensaje de advertencia si el usuario intenta acceder al menú de otro usuario
            callback_query.answer("Abre tu propio Menú ⚠️")
            return
    # Continuar la propagación de la consulta
    callback_query.continue_propagation()

# Configuración de logs
logging.basicConfig(level=logging.INFO)

# Ejecutar el cliente
Anonymous.run()
