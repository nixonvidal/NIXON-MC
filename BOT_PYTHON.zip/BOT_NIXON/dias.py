import sqlite3
from datetime import datetime, timedelta

# Función para calcular los días restantes
def calcular_dias_restantes(fecha_registro, dias):
    tiempo_actual = datetime.now().timestamp()
    segundos_restantes = (fecha_registro.timestamp() + (dias * 24 * 60 * 60)) - tiempo_actual
    dias_restantes = segundos_restantes / (24 * 60 * 60)
    return dias_restantes

# Conectar a la base de datos
conn = sqlite3.connect('usuarios.db')
cursor = conn.cursor()

# Obtener la cantidad de días que se establecerán (puedes solicitar esto al usuario)
nuevos_dias = int(input("Ingrese la nueva cantidad de días: "))

# Obtener la fecha y hora actual
nueva_fecha_registro = datetime.now().strftime('%Y-%m-%d')

# Actualizar la cantidad de días y la fecha de registro para el usuario con ID 2
cursor.execute("UPDATE usuarios SET dias = ?, fecha_registro = ? WHERE id = ?", (nuevos_dias, nueva_fecha_registro, 1))


# Obtener datos del usuario con ID 2
cursor.execute("SELECT dias, fecha_registro FROM usuarios WHERE id = ?", (1,))
usuario = cursor.fetchone()

if usuario:
    dias_restantes, fecha_registro_str = usuario
    fecha_registro = datetime.strptime(fecha_registro_str, '%Y-%m-%d')

    # Calcular los días restantes
    dias_restantes = calcular_dias_restantes(fecha_registro, dias_restantes)

    # Verificar si el plan ha expirado
    if dias_restantes <= 0:
        print("El plan ha expirado.")
    else:
        print(f"El plan aún no ha expirado. Quedan {int(dias_restantes)} días.")

# Guardar los cambios y cerrar la conexión
conn.commit()
conn.close()
