#!/bin/bash

# Colores para resaltar los mensajes
GREEN='\033[0;32m'
NC='\033[0m' # No Color

# Función para limpiar la pantalla
clear_screen() {
    if [ "$OSTYPE" == "linux-gnu" ]; then
        clear
    elif [ "$OSTYPE" == "darwin"* ]; then
        clear
    elif [ "$OSTYPE" == "cygwin" ]; then
        clear
    elif [ "$OSTYPE" == "msys" ]; then
        clear
    elif [ "$OSTYPE" == "win32" ]; then
        cls
    fi
}

# Función para instalar Python 3.12.2
install_python() {
    clear_screen
    echo -e "${GREEN}Iniciando la instalación de Python 3.12.2...${NC}"
    if [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
        echo "Este script solo está diseñado para sistemas Unix-like. Por favor, instala Python manualmente en Windows."
        exit 1
    fi

    # Actualiza el sistema
    sudo apt update
    sudo apt upgrade -y

    # Instala las dependencias necesarias
    sudo apt install -y build-essential libssl-dev wget

    # Descarga el código fuente de Python 3.12.2
    wget https://www.python.org/ftp/python/3.12.2/Python-3.12.2.tgz

    # Descomprime el archivo
    tar -xzvf Python-3.12.2.tgz

    # Navega al directorio Python-3.12.2
    cd Python-3.12.2 || exit

    # Configura y compila Python
    ./configure --enable-optimizations
    make -j"$(nproc)"

    # Instala Python
    sudo make altinstall

    # Agrega el nuevo PATH al archivo ~/.bashrc
    echo 'export PATH=/usr/local/bin:$PATH' >> ~/.bashrc

    # Recarga el archivo ~/.bashrc
    source ~/.bashrc

    sudo ln -s /usr/local/bin/python3.12 /usr/local/bin/python
    
    # Verifica la instalación
    clear_screen
    echo -e "${GREEN}Python 3.12.2 ha sido instalado correctamente.${NC}"
    python --version
}

# Llama a la función para instalar Python
install_python
