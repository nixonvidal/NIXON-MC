import sqlite3
from datetime import datetime

# Función para calcular los días restantes
def calcular_dias_restantes(fecha_registro, dias):
    tiempo_actual = datetime.now().timestamp()
    segundos_restantes = (fecha_registro.timestamp() + (dias * 24 * 60 * 60)) - tiempo_actual
    dias_restantes = segundos_restantes / (24 * 60 * 60)
    return dias_restantes

# Conectar a la base de datos
conn = sqlite3.connect('usuarios.db')
cursor = conn.cursor()
dias_a_agregar = int(input("Ingrese la cantidad de días a agregar: "))

# Actualizar la cantidad de días para el usuario con ID 2
cursor.execute("UPDATE usuarios SET dias = dias + ? WHERE id = ?", (dias_a_agregar, 2))
# Obtener datos de un usuario específico (cambia el ID del usuario según necesites)
cursor.execute("SELECT dias, fecha_registro FROM usuarios WHERE id = ?", (2,))
usuario = cursor.fetchone()

if usuario:
    dias_restantes, fecha_registro = usuario
    fecha_registro = datetime.fromisoformat(fecha_registro)

    # Calcular los días restantes
    dias_restantes = calcular_dias_restantes(fecha_registro, dias_restantes)

    # Verificar si el plan ha expirado
    if dias_restantes <= 0:
        print("El plan ha expirado.")
    else:
        print(f"El plan aún no ha expirado. {int(dias_restantes)}")

# Cerrar la conexión
conn.close()
