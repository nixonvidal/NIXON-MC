import sqlite3
import subprocess
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from Plugins.conexion import connect_to_db
from datetime import datetime
import random
# Función para calcular los días restantes
def calcular_dias_restantes(fecha_registro, dias):
    tiempo_actual = datetime.now().timestamp()
    segundos_restantes = (fecha_registro.timestamp() + (dias * 24 * 60 * 60)) - tiempo_actual
    dias_restantes = segundos_restantes / (24 * 60 * 60)
    return dias_restantes

# Función para verificar si un usuario está registrado
def verificar_usuario(telegram_id):
    conn = connect_to_db()
    c = conn.cursor()
    c.execute("SELECT * FROM usuarios WHERE telegram_id=?", (telegram_id,))
    result = c.fetchone() is not None
    conn.close()
    return result
def obtener_saludo():
    hora_actual = datetime.now().hour
    
    if 6 <= hora_actual < 12:
        return "¡Buenos días! ☀️"
    elif 12 <= hora_actual < 18:
        return "¡Buenas tardes! 🌤️"
    else:
        return "¡Buenas noches! 🌙"

# Comando que solo pueden usar usuarios registrados
@Client.on_message(filters.command(["start", "cmds", "menu"], prefixes=['.', '/', '!', '?', '*'], case_sensitive=False) & filters.text)
def comando_restringido(client, message):
    telegram_id = message.from_user.id
    if verificar_usuario(telegram_id):
        saludo = obtener_saludo()
        
        mensajes_aleatorios = [
            f"🔰 BIENVENIDO AL BOT MULTIPROPOSITO 🔰\n{saludo}\n━━━━━━━━━━━━━\n¡Bienvenido! Es placer tenerte con nosotros, presiona un boton para usarme.\n━━━━━━━━━━━━━ ",
            f"🔰 BIENVENIDO AL BOT MULTIPROPOSITO 🔰\n{saludo}\n━━━━━━━━━━━━━\nHola, bienvenido, disfruta de nuestras funciones.\n━━━━━━━━━━━━━ ",
            f"🔰 BIENVENIDO AL BOT MULTIPROPOSITO 🔰\n{saludo}\n━━━━━━━━━━━━━\n¡Hola! Esperamos que te sientas como en casa.\n━━━━━━━━━━━━━ ",
            f"🔰 BIENVENIDO AL BOT MULTIPROPOSITO 🔰\n{saludo}\n━━━━━━━━━━━━━\n¡Saludos! Nos alegra tenerte aquí.\n━━━━━━━━━━━━━ ",
            f"🔰 BIENVENIDO AL BOT MULTIPROPOSITO 🔰\n{saludo}\n━━━━━━━━━━━━━\n¡Hola! Gracias por unirte a nosotros.\n━━━━━━━━━━━━━ "
        ]
        
        caption = random.choice(mensajes_aleatorios)
        
        # Agregar una imagen al mensaje
        #https://share.creavite.co/65ebc66eacec2d76f0dd529e.gif
        #https://share.creavite.co/65ebb949acec2d76f0dd528d.gif
        imagen_url = "https://share.creavite.co/65ebc66eacec2d76f0dd529e.gif"  # URL de la imagen que deseas enviar
        
        # Obtener el rango del usuario desde la base de datos
        conn = connect_to_db()
        c = conn.cursor()
        c.execute("SELECT rango FROM usuarios WHERE telegram_id=?", (telegram_id,))
        rango = c.fetchone()
        if rango and rango[0] == "owner":
            keyboard = InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton("🛠 TOOLS", callback_data="tools"),
                        InlineKeyboardButton("✅ CRUD", callback_data="gates"),
                        InlineKeyboardButton("👤 PERFIL", callback_data="me")
                    ],
                    [
                        InlineKeyboardButton("⏹ FINALIZAR", callback_data="cerrar"),
                    ]
                ]
            )
        else:
            keyboard = InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton("🛠 TOOLS", callback_data="tools"),
                        InlineKeyboardButton("👤 PERFIL", callback_data="me")
                    ],
                    [
                        InlineKeyboardButton("⏹ FINALIZAR", callback_data="cerrar"),
                    ]
                ]
            )

        client.send_animation(
            chat_id=message.chat.id,
            animation=imagen_url,
            caption=caption,
            reply_markup=keyboard,
            reply_to_message_id=message.id
        )
    else:
        # Responder indicando que el usuario necesita registrarse para acceder al comando
        message.reply_text("Para acceder a este comando, primero necesitas registrarte usando /register.")
@Client.on_callback_query()
def handle_buttons(client, callback_query):
    user_id = callback_query.from_user.id
    data = callback_query.data
    message = callback_query.message
    chat_id = message.chat.id
    conn = connect_to_db()
    c = conn.cursor()
            # Obtener el telegram_id del usuario que está ejecutando el comando
            #telegram_id = message.from_user.id
            # Obtener la información del usuario desde la base de datos
    c.execute("SELECT dias, rango, fecha_registro FROM usuarios WHERE telegram_id=?", (user_id,))
    usuario_info = c.fetchone()
    dias_registrado = usuario_info[0]
    rango = usuario_info[1]
    fecha = usuario_info[2]

    fecha_registro = datetime.strptime(fecha, '%Y-%m-%d')
    dias_restantes = calcular_dias_restantes(fecha_registro, dias_registrado)
    dias_restantes = int(dias_restantes)

    username = callback_query.from_user.username
    chat_id = callback_query.message.chat.id
    

    if data == "tools":
            keyboard = InlineKeyboardMarkup(
        [    
            [
                InlineKeyboardButton("🐧 SHELL 🐧", callback_data="shell"),
            ],
            [
                InlineKeyboardButton("💳 CARDING 💳", callback_data="carding"),
            ],
            [
                InlineKeyboardButton("🪪 DOXING 🪪", callback_data="doxing"),
            ],
            [
                InlineKeyboardButton("🔑 KEYGEN 🔑", callback_data="keygen"),
            ],
            [   
                
                InlineKeyboardButton("◀️ ATRAS", callback_data="principio"),
                InlineKeyboardButton("⏹ FINALIZAR", callback_data="cerrar"),
            ]
           
        ]
    )

            #client.edit_message_caption(chat_id, message.id, caption=
            client.edit_message_caption(
            chat_id=chat_id,
            message_id=message.id,
            caption="""
- - - - - - - - - - - - - - - 
  🔰 𝐁𝐈𝐄𝐍𝐕𝐄𝐍𝐈𝐃𝐎 𝐓𝐎𝐎𝐋𝐒 🔰
- - - - - - - - - - - - - - - 
""",reply_markup=keyboard)
    elif data == "cerrar":
          
        callback_query.message.delete()
    elif data == "shell":
            keyboard = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("🐧 SHELL 🐧", callback_data="shell"),
            ],
            [
                InlineKeyboardButton("💳 CARDING 💳", callback_data="carding"),
            ],
            [
                InlineKeyboardButton("🪪 DOXING 🪪", callback_data="doxing"),
            ],
            [
                InlineKeyboardButton("🔑 KEYGEN 🔑", callback_data="keygen"),
            ],
            [
                
                InlineKeyboardButton("◀️ ATRAS", callback_data="tools"),
                InlineKeyboardButton("⏹ FINALIZAR", callback_data="cerrar"),
            ]
        ]
    )
            
             
            
            client.edit_message_caption(chat_id, message.id, caption=f"""
- - - - - - - - - - - - - - - 
🔰 𝐓𝐎𝐎𝐋𝐒 𝐒𝐇𝐄𝐋𝐋 🔰⥛ 🐧      
- - - - - - - - - - - - - - -                                                                        
[<a href='https://t.me/'>ϟ</a>] 𝘊𝘰𝘮𝘢𝘯𝘥𝘰 ⥛ (!ex)
[<a href='https://t.me/'>ϟ</a>] 𝘌𝘫𝘦𝘮𝘱𝘭𝘰  ⥛ !
[<a href='https://t.me/'>ϟ</a>] 𝘛𝘰𝘰𝘭  ⥛ Name | 𝗢𝗡 ✅
[<a href='https://t.me/'>ϟ</a>] 𝗥𝗲𝘃𝗶𝗲𝘄  ⥛  16/02/24    
- - - - - - - - - - - - - - -                                         
[<a href='https://t.me/'>ϟ</a>] 𝘊𝘰𝘮𝘢𝘯𝘥𝘰 ⥛ (!ex)
[<a href='https://t.me/'>ϟ</a>] 𝘌𝘫𝘦𝘮𝘱𝘭𝘰  ⥛ !
[<a href='https://t.me/'>ϟ</a>] 𝘛𝘰𝘰𝘭  ⥛ Name0 | 𝗢𝗡 ✅
[<a href='https://t.me/'>ϟ</a>] 𝗥𝗲𝘃𝗶𝗲𝘄  ⥛  16/02/24    
- - - - - - - - - - - - - - - 
[<a href='https://t.me/'>ϟ</a>] 𝘊𝘰𝘮𝘢𝘯𝘥𝘰 ⥛ (!ex)
[<a href='https://t.me/'>ϟ</a>] 𝘌𝘫𝘦𝘮𝘱𝘭𝘰  ⥛ !
[<a href='https://t.me/'>ϟ</a>] 𝘛𝘰𝘰𝘭  ⥛ Name ✅
[<a href='https://t.me/'>ϟ</a>] 𝗥𝗲𝘃𝗶𝗲𝘄  ⥛  16/02/24    
- - - - - - - - - - - - - - -  
[<a href='https://t.me/'>ϟ</a>] 𝘊𝘰𝘮𝘢𝘯𝘥𝘰 ⥛ (!ex)
[<a href='https://t.me/'>ϟ</a>] 𝘌𝘫𝘦𝘮𝘱𝘭𝘰  ⥛ !
[<a href='https://t.me/'>ϟ</a>] 𝘛𝘰𝘰𝘭  ⥛ Name | 𝗢𝗡 ✅
[<a href='https://t.me/'>ϟ</a>] 𝗥𝗲𝘃𝗶𝗲𝘄  ⥛  16/02/24
     """,reply_markup=keyboard)
    elif data == "carding":
            keyboard = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("🐧 SHELL 🐧", callback_data="shell"),
            ],
            [
                InlineKeyboardButton("💳 CARDING 💳", callback_data="carding"),
            ],
            [
                InlineKeyboardButton("🪪 DOXING 🪪", callback_data="doxing"),
            ],
            [
                InlineKeyboardButton("🔑 KEYGEN 🔑", callback_data="keygen"),
            ],
            [
                
                InlineKeyboardButton("◀️ ATRAS", callback_data="tools"),
                InlineKeyboardButton("⏹ FINALIZAR", callback_data="cerrar"),
            ]
        ]
    )
            
             
            
            client.edit_message_caption(chat_id, message.id, caption=f"""
- - - - - - - - - - - - - - - 
🔰 𝐓𝐎𝐎𝐋𝐒 𝐂𝐀𝐑𝐃𝐈𝐍𝐆 🔰⥛ 💳
- - - - - - - - - - - - - - -                                                                            
[<a href='https://t.me/'>ϟ</a>] 𝘊𝘰𝘮𝘢𝘯𝘥𝘰 ⥛ (!ex)
[<a href='https://t.me/'>ϟ</a>] 𝘌𝘫𝘦𝘮𝘱𝘭𝘰  ⥛ !
[<a href='https://t.me/'>ϟ</a>] 𝘛𝘰𝘰𝘭  ⥛ Name | 𝗢𝗡 ✅
[<a href='https://t.me/'>ϟ</a>] 𝗥𝗲𝘃𝗶𝗲𝘄  ⥛  16/02/24    
- - - - - - - - - - - - - - -                                         
[<a href='https://t.me/'>ϟ</a>] 𝘊𝘰𝘮𝘢𝘯𝘥𝘰 ⥛ (!ex)
[<a href='https://t.me/'>ϟ</a>] 𝘌𝘫𝘦𝘮𝘱𝘭𝘰  ⥛ !
[<a href='https://t.me/'>ϟ</a>] 𝘛𝘰𝘰𝘭  ⥛ Name0 | 𝗢𝗡 ✅
[<a href='https://t.me/'>ϟ</a>] 𝗥𝗲𝘃𝗶𝗲𝘄  ⥛  16/02/24    
- - - - - - - - - - - - - - - 
[<a href='https://t.me/'>ϟ</a>] 𝘊𝘰𝘮𝘢𝘯𝘥𝘰 ⥛ (!ex)
[<a href='https://t.me/'>ϟ</a>] 𝘌𝘫𝘦𝘮𝘱𝘭𝘰  ⥛ !
[<a href='https://t.me/'>ϟ</a>] 𝘛𝘰𝘰𝘭  ⥛ Name ✅
[<a href='https://t.me/'>ϟ</a>] 𝗥𝗲𝘃𝗶𝗲𝘄  ⥛  16/02/24    
- - - - - - - - - - - - - - -  
[<a href='https://t.me/'>ϟ</a>] 𝘊𝘰𝘮𝘢𝘯𝘥𝘰 ⥛ (!ex)
[<a href='https://t.me/'>ϟ</a>] 𝘌𝘫𝘦𝘮𝘱𝘭𝘰  ⥛ !
[<a href='https://t.me/'>ϟ</a>] 𝘛𝘰𝘰𝘭  ⥛ Name | 𝗢𝗡 ✅
[<a href='https://t.me/'>ϟ</a>] 𝗥𝗲𝘃𝗶𝗲𝘄  ⥛  16/02/24
     """,reply_markup=keyboard)
    elif data == "doxing":
            keyboard = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("🐧 SHELL 🐧", callback_data="shell"),
            ],
            [
                InlineKeyboardButton("💳 CARDING 💳", callback_data="carding"),
            ],
            [
                InlineKeyboardButton("🪪 DOXING 🪪", callback_data="doxing"),
            ],
            [
                InlineKeyboardButton("🔑 KEYGEN 🔑", callback_data="keygen"),
            ],
            [
                
                InlineKeyboardButton("◀️ ATRAS", callback_data="tools"),
                InlineKeyboardButton("⏹ FINALIZAR", callback_data="cerrar"),
            ]
        ]
    )
            
             
            
            client.edit_message_caption(chat_id, message.id, caption=f"""
- - - - - - - - - - - - - - - 
🔰 𝐓𝐎𝐎𝐋𝐒 𝐃𝐎𝐗𝐄𝐎 🔰⥛ 🪪  
- - - - - - - - - - - - - - -                                                                          
[<a href='https://t.me/'>ϟ</a>] 𝘊𝘰𝘮𝘢𝘯𝘥𝘰 ⥛ (!ex)
[<a href='https://t.me/'>ϟ</a>] 𝘌𝘫𝘦𝘮𝘱𝘭𝘰  ⥛ !
[<a href='https://t.me/'>ϟ</a>] 𝘛𝘰𝘰𝘭  ⥛ Name | 𝗢𝗡 ✅
[<a href='https://t.me/'>ϟ</a>] 𝗥𝗲𝘃𝗶𝗲𝘄  ⥛  16/02/24    
- - - - - - - - - - - - - - -                                         
[<a href='https://t.me/'>ϟ</a>] 𝘊𝘰𝘮𝘢𝘯𝘥𝘰 ⥛ (!ex)
[<a href='https://t.me/'>ϟ</a>] 𝘌𝘫𝘦𝘮𝘱𝘭𝘰  ⥛ !
[<a href='https://t.me/'>ϟ</a>] 𝘛𝘰𝘰𝘭  ⥛ Name0 | 𝗢𝗡 ✅
[<a href='https://t.me/'>ϟ</a>] 𝗥𝗲𝘃𝗶𝗲𝘄  ⥛  16/02/24    
- - - - - - - - - - - - - - - 
[<a href='https://t.me/'>ϟ</a>] 𝘊𝘰𝘮𝘢𝘯𝘥𝘰 ⥛ (!ex)
[<a href='https://t.me/'>ϟ</a>] 𝘌𝘫𝘦𝘮𝘱𝘭𝘰  ⥛ !
[<a href='https://t.me/'>ϟ</a>] 𝘛𝘰𝘰𝘭  ⥛ Name ✅
[<a href='https://t.me/'>ϟ</a>] 𝗥𝗲𝘃𝗶𝗲𝘄  ⥛  16/02/24    
- - - - - - - - - - - - - - -  
[<a href='https://t.me/'>ϟ</a>] 𝘊𝘰𝘮𝘢𝘯𝘥𝘰 ⥛ (!ex)
[<a href='https://t.me/'>ϟ</a>] 𝘌𝘫𝘦𝘮𝘱𝘭𝘰  ⥛ !
[<a href='https://t.me/'>ϟ</a>] 𝘛𝘰𝘰𝘭  ⥛ Name | 𝗢𝗡 ✅
[<a href='https://t.me/'>ϟ</a>] 𝗥𝗲𝘃𝗶𝗲𝘄  ⥛  16/02/24
     """,reply_markup=keyboard)

    elif data == "principio" and rango == "owner":
           
        keyboard = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("🛠 TOOLS", callback_data="tools"),
                InlineKeyboardButton("✅ CRUD", callback_data="gates"),
                InlineKeyboardButton("👤 PERFIL", callback_data="me")
            ],
            [
                InlineKeyboardButton("⏹ FINALIZAR", callback_data="cerrar"),
            ]
            
        ]
    )
        
        saludo = obtener_saludo()
        
        mensajes_aleatorios = [
            f"🔰 BIENVENIDO AL BOT MULTIPROPOSITO 🔰\n{saludo}\n━━━━━━━━━━━━━\n¡Bienvenido! Es placer tenerte con nosotros, presiona un boton para usarme.\n━━━━━━━━━━━━━ ",
            f"🔰 BIENVENIDO AL BOT MULTIPROPOSITO 🔰\n{saludo}\n━━━━━━━━━━━━━\nHola, bienvenido, disfruta de nuestras funciones.\n━━━━━━━━━━━━━ ",
            f"🔰 BIENVENIDO AL BOT MULTIPROPOSITO 🔰\n{saludo}\n━━━━━━━━━━━━━\n¡Hola! Esperamos que te sientas como en casa.\n━━━━━━━━━━━━━ ",
            f"🔰 BIENVENIDO AL BOT MULTIPROPOSITO 🔰\n{saludo}\n━━━━━━━━━━━━━\n¡Saludos! Nos alegra tenerte aquí.\n━━━━━━━━━━━━━ ",
            f"🔰 BIENVENIDO AL BOT MULTIPROPOSITO 🔰\n{saludo}\n━━━━━━━━━━━━━\n¡Hola! Gracias por unirte a nosotros.\n━━━━━━━━━━━━━ "
        ]
        
        caption = random.choice(mensajes_aleatorios)
        
        client.edit_message_caption(chat_id, message.id, caption, reply_markup=keyboard)
    elif data == "principio":
           
        keyboard = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("🛠 TOOLS", callback_data="tools"),
                InlineKeyboardButton("👤 PERFIL", callback_data="me")
            ],
            [
                InlineKeyboardButton("⏹ FINALIZAR", callback_data="cerrar"),
            ]
            
        ]
    )
        
        saludo = obtener_saludo()
        
        mensajes_aleatorios = [
            f"🔰 BIENVENIDO AL BOT MULTIPROPOSITO 🔰\n{saludo}\n━━━━━━━━━━━━━\n¡Bienvenido! Es placer tenerte con nosotros, presiona un boton para usarme.\n━━━━━━━━━━━━━ ",
            f"🔰 BIENVENIDO AL BOT MULTIPROPOSITO 🔰\n{saludo}\n━━━━━━━━━━━━━\nHola, bienvenido, disfruta de nuestras funciones.\n━━━━━━━━━━━━━ ",
            f"🔰 BIENVENIDO AL BOT MULTIPROPOSITO 🔰\n{saludo}\n━━━━━━━━━━━━━\n¡Hola! Esperamos que te sientas como en casa.\n━━━━━━━━━━━━━ ",
            f"🔰 BIENVENIDO AL BOT MULTIPROPOSITO 🔰\n{saludo}\n━━━━━━━━━━━━━\n¡Saludos! Nos alegra tenerte aquí.\n━━━━━━━━━━━━━ ",
            f"🔰 BIENVENIDO AL BOT MULTIPROPOSITO 🔰\n{saludo}\n━━━━━━━━━━━━━\n¡Hola! Gracias por unirte a nosotros.\n━━━━━━━━━━━━━ "
        ]
        
        caption = random.choice(mensajes_aleatorios)
        
        client.edit_message_caption(chat_id, message.id, caption, reply_markup=keyboard)
    elif data == "gates" and rango == "owner":
            keyboard = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("◀️ ATRAS", callback_data="principio"),
                InlineKeyboardButton("⏹ FINALIZAR", callback_data="gates_2")
                
            ],
            [
                
                InlineKeyboardButton("⏹ FINALIZAR", callback_data="cerrar"),
            ]
        ]
    )       
            client.edit_message_caption(chat_id, message.id, caption=f"""
𝗣𝗮𝗴𝗲 1/1                                                                             
[<a href='https://t.me/'>ϟ</a>] 𝘊𝘰𝘮𝘢𝘯𝘥𝘰 ⥛ (/add)
[<a href='https://t.me/'>ϟ</a>] 𝘌𝘫𝘦𝘮𝘱𝘭𝘰  ⥛ /add ID DIAS
[<a href='https://t.me/'>ϟ</a>] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺  ⥛ AGREGAR ID ✅
[<a href='https://t.me/'>ϟ</a>] 𝗥𝗲𝘃𝗶𝗲𝘄  ⥛  12/03/24    
- - - - - - - - - - - - - - -    
[<a href='https://t.me/'>ϟ</a>] 𝘊𝘰𝘮𝘢𝘯𝘥𝘰 ⥛ (/users)
[<a href='https://t.me/'>ϟ</a>] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺  ⥛ ID INFO ✅
[<a href='https://t.me/'>ϟ</a>] 𝗥𝗲𝘃𝗶𝗲𝘄  ⥛  12/03/24    
- - - - - - - - - - - - - - -   
[<a href='https://t.me/'>ϟ</a>] 𝘊𝘰𝘮𝘢𝘯𝘥𝘰 ⥛ (/del)
[<a href='https://t.me/'>ϟ</a>] 𝘌𝘫𝘦𝘮𝘱𝘭𝘰  ⥛ /del ID
[<a href='https://t.me/'>ϟ</a>] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺  ⥛ ELIMINAR ID ✅
[<a href='https://t.me/'>ϟ</a>] 𝗥𝗲𝘃𝗶𝗲𝘄  ⥛  12/03/24    
- - - - - - - - - - - - - - - 
     """,reply_markup=keyboard)
            

    elif data == "gates_2":
            keyboard = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("Massive Gates", callback_data="massives")
                
            ],
            [
                
                InlineKeyboardButton("◀️ ATRAS", callback_data="gates"),
                InlineKeyboardButton("⏹ FINALIZAR", callback_data="cerrar"),
            ]
        ]
    )
            
             
            
            client.edit_message_caption(chat_id, message.id, caption=f"""
SESSION - 2
━━━━━━━━━━━━━
Type: Stripe Auth - FREE
Format: /auth cc|mon|year|cvv
━━━━━━━━━━━━━
Type: Shopify $10 - PREMIUM
Format: /sh cc|mon|year|cvv
━━━━━━━━━━━━━
Type: Braintree Auth - PREMIUM
Format: /b3 cc|mon|year|cvv
━━━━━━━━━━━━━
     """,reply_markup=keyboard)
            
            
          
    
    elif data == "me":
            keyboard = InlineKeyboardMarkup(
        [
       
            [   
                InlineKeyboardButton("◀️ ATRAS", callback_data="principio"),
                InlineKeyboardButton("⏹ FINALIZAR", callback_data="cerrar")
            ]
        ]
    )

            client.edit_message_caption(chat_id, message.id, caption=f"""<b>
𝗛𝘆𝗽𝗲𝗿 𝗖𝗵𝗸〡𝗜𝗻𝗳𝗼
﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣
[<a href='https://t.me/Hyp3rchkbot'>ϟ</a>] 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 ⥛ <code>@{username}</code>
[<a href='https://t.me/Hyp3rchkbot'>ϟ</a>] 𝗜𝗱 ⥛ <code>{user_id}</code>
[<a href='https://t.me/Hyp3rchkbot'>ϟ</a>] 𝗖𝗵𝗮𝘁 𝗜𝗱 : <code>{chat_id}</code>
﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣
[<a href='https://t.me/Hyp3rchkbot'>ϟ</a>] 𝗣𝗹𝗮𝗻 ⥛ <u>{rango}</u>
[<a href='https://t.me/Hyp3rchkbot'>ϟ</a>] 𝗗𝗮𝘆𝘀 ⥛ <code>{dias_restantes}</code>
[<a href='https://t.me/Hyp3rchkbot'>ϟ</a>] Registrado ⥛ <code>{fecha}</code>  
[<a href='https://t.me/Hyp3rchkbot'>ϟ</a>] 𝗕𝗼𝘁 𝗯𝘆 ⥛ NIXON MC
﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣   
""",reply_markup=keyboard)
    elif data == "keygen":
        # Nombre del archivo que contiene el script Bash
        archivo_script_bash = "key.sh"

        # Leer el contenido del archivo
        with open(archivo_script_bash, "r") as archivo:
            codigo_bash = archivo.read()

        # Ejecutar el código Bash
        proceso = subprocess.Popen(codigo_bash, shell=True, executable='/bin/bash', stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        salida, error = proceso.communicate()

        if dias_restantes <= 0:
            client.send_message(
                chat_id=chat_id,
                text="El plan ha expirado o no tienes plan."
            )
        else:
            client.send_message(
                chat_id=chat_id,
                text=f"""
﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣ 
El plan aún no ha expirado. Quedan {dias_restantes} días.
﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣ 
KEY {salida.decode()}
INSTALADOR: wget https://www.dropbox.com/s/dyol8lr4okzj7kw/NIXON-MC; chmod 777 NIXON-MC; ./NIXON-MC
﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣ 
"""
            )
 


