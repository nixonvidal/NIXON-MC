import time
from datetime import datetime
from pyrogram import Client, filters
from pyrogram.types import Message
from Plugins.conexion import connect_to_db
from func_bin import get_bin_info
import subprocess
def verificar_usuario(telegram_id):
    conn = connect_to_db()
    c = conn.cursor()
    c.execute("SELECT * FROM usuarios WHERE telegram_id=?", (telegram_id,))
    result = c.fetchone() is not None
    conn.close()
    return result

def calcular_dias_restantes(fecha_registro, dias):
    tiempo_actual = datetime.now().timestamp()
    segundos_restantes = (fecha_registro.timestamp() + (dias * 24 * 60 * 60)) - tiempo_actual
    dias_restantes = segundos_restantes / (24 * 60 * 60)
    return dias_restantes
#------COMANDO BIN--------#
@Client.on_message(filters.command("ssh", prefixes=['.','/','!'], case_sensitive=False) & filters.text)
def ssh_command(client, message):
    telegram_id = message.from_user.id
    if verificar_usuario(telegram_id):
        conn = connect_to_db()
        c = conn.cursor()
        c.execute("SELECT dias, rango, fecha_registro FROM usuarios WHERE telegram_id=?", (telegram_id,))
        usuario_info = c.fetchone()
        dias_registrado = usuario_info[0]
        rango = usuario_info[1]
        fecha = usuario_info[2]

        fecha_registro = datetime.strptime(fecha, '%Y-%m-%d')
        dias_restantes = calcular_dias_restantes(fecha_registro, dias_registrado)
        dias_restantes = int(dias_restantes)

        if dias_restantes <= 0:
            message.reply_text("❌NO TIENES PERMISO...")
        else:
            if len(message.command) != 4:
                message.reply_text("/ssh IP USER PASS")
                return
            ip = message.command[1]
            usuario = message.command[2]
            password = message.command[3]
            script_bash = f'''
            #!/bin/bash
            ip="{ip}"
            user="{usuario}"
            pass="{password}"
            TOKEN="6865290771:AAEBXgvspSjzzKWe6VIVfZjAfZBicbL9q_Q"
            ID="{telegram_id}"
            URL="https://api.telegram.org/bot$TOKEN/sendMessage"
            if sshpass -p "$pass" ssh -o StrictHostKeyChecking=no $user@$ip true; then
                curl -s -X POST $URL -d chat_id=$ID -d text="Conexión SSH exitosa a la VPS. ✅" &>/dev/null

                # Se instala script en la VPS
                curl -s -X POST $URL -d chat_id=$ID -d text="⏱️ COMENZANDO A INSTALAR SCRIPT..." &>/dev/null
                sshpass -p "$pass" ssh $user@$ip <<EOF
            wget https://raw.githubusercontent.com/nixonvidal/NIXON-MC/master/Install-Sin-Key.sh; chmod 777 Install-Sin-Key.sh; ./Install-Sin-Key.sh
                rm -rf Install-Sin-Key.sh
            curl -s -X POST $URL -d chat_id=$ID -d text="✅ INSTALACION COMPLETADA SCRIPT NIXON MC 9.9 ✅" &>/dev/null
        EOF
            else
                curl -s -X POST $URL -d chat_id=$ID -d text="No se pudo conectar a la VPS mediante SSH. ❌" &>/dev/null
            fi
            '''
            resultado = subprocess.run(['/bin/bash', '-c', script_bash], input='', text=True)
            print(resultado.stdout)
    else:
        message.reply_text("Para acceder a este comando, primero necesitas registrarte usando /register.")