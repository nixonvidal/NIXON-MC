from datetime import datetime
from pyrogram.types import Message
from Plugins.conexion import connect_to_db
import requests
from pyrogram import Client, filters

#------FUNCIONES AUXILIARES--------#

def verificar_usuario(telegram_id):
    conn = connect_to_db()
    c = conn.cursor()
    c.execute("SELECT * FROM usuarios WHERE telegram_id=?", (telegram_id,))
    result = c.fetchone() is not None
    conn.close()
    return result

def calcular_dias_restantes(fecha_registro, dias):
    tiempo_actual = datetime.now().timestamp()
    segundos_restantes = (fecha_registro.timestamp() + (dias * 24 * 60 * 60)) - tiempo_actual
    dias_restantes = segundos_restantes / (24 * 60 * 60)
    return dias_restantes

#------COMANDO NYA--------#

@Client.on_message(filters.command("nya", prefixes=['.','/','!'], case_sensitive=False))
def nya_comando(client, message):
    telegram_id = message.from_user.id
    if not verificar_usuario(telegram_id):
        message.reply_text("Para acceder a este comando, primero necesitas registrarte usando /register.")
        return
    
    conn = connect_to_db()
    c = conn.cursor()
    c.execute("SELECT dias, rango, fecha_registro FROM usuarios WHERE telegram_id=?", (telegram_id,))
    usuario_info = c.fetchone()
    dias_registrado = usuario_info[0]
    rango = usuario_info[1]
    fecha = usuario_info[2]

    fecha_registro = datetime.strptime(fecha, '%Y-%m-%d')
    dias_restantes = calcular_dias_restantes(fecha_registro, dias_registrado)
    dias_restantes = int(dias_restantes)
    if dias_restantes <= 0:
        message.reply_text("❌NO TIENES PERMISO...")
        return
    
    try:
        # Obtener los nombres y apellidos del comando
        command_text = message.text.split(' ', 1)[1]
        nombres, apellidoPaterno, apellidoMaterno = command_text.split('|')
        
        url = f"https://nixonmc.online/index.php?nya={nombres}|{apellidoPaterno}|{apellidoMaterno}"  # Construir la URL para la consulta
        
        # Autenticación básica
        auth = ("cat", "catpass")

        response = requests.get(url, auth=auth)  # Realizar la solicitud HTTP con autenticación básica
        
        if response.status_code == 200:
            # Si la solicitud fue exitosa, procesar la respuesta
            data_list = response.json()
            if isinstance(data_list, dict) and "error" in data_list:
                message.reply_text("Nombre  no encontrado")
            if isinstance(data_list, list):  # Verificar si la respuesta es una lista
                for data in data_list:  # Iterar sobre los objetos JSON en la lista
                    message.reply_text(f"""
DNI: {data["DNI"]}
Apellido Paterno: {data["AP_PAT"]}
Apellido Materno: {data["AP_MAT"]}
Nombres: {data["NOMBRES"]}
Fecha de Nacimiento: {data["FECHA_NAC"]}
Fecha de Inscripción: {data["FCH_INSCRIPCION"]}
Fecha de Emisión: {data["FCH_EMISION"]}
Fecha de Caducidad: {data["FCH_CADUCIDAD"]}
Ubigeo de Nacimiento: {data["UBIGEO_NAC"]}
Ubigeo de Dirección: {data["UBIGEO_DIR"]}
Dirección: {data["DIRECCION"]}
Sexo: {data["SEXO"]}
Estado Civil: {data["EST_CIVIL"]}
Dígito RUC: {data["DIG_RUC"]}
Madre: {data["MADRE"]}
Padre: {data["PADRE"]}
                """)
        else:
            # Si hay un error en la solicitud, informar al usuario
            message.reply_text("Error al procesar la solicitud.")
    except IndexError:
        message.reply_text("Por favor, ingresa nombres y apellidos después del comando en el formato nombres|apellidoPaterno|apellidoMaterno.")
    except Exception as e:
        message.reply_text(f"Se produjo un error: {str(e)}")
