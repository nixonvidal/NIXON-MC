import time
from datetime import datetime
from pyrogram import Client, filters
from pyrogram.types import Message
from Plugins.conexion import connect_to_db
from func_bin import get_bin_info
def verificar_usuario(telegram_id):
    conn = connect_to_db()
    c = conn.cursor()
    c.execute("SELECT * FROM usuarios WHERE telegram_id=?", (telegram_id,))
    result = c.fetchone() is not None
    conn.close()
    return result

def calcular_dias_restantes(fecha_registro, dias):
    tiempo_actual = datetime.now().timestamp()
    segundos_restantes = (fecha_registro.timestamp() + (dias * 24 * 60 * 60)) - tiempo_actual
    dias_restantes = segundos_restantes / (24 * 60 * 60)
    return dias_restantes
#------COMANDO BIN--------#
@Client.on_message(filters.command("bin", prefixes=['.','/','!'], case_sensitive=False) & filters.text)
def bin_handler(client, message):
    telegram_id = message.from_user.id
    if verificar_usuario(telegram_id):
        conn = connect_to_db()
        c = conn.cursor()
        c.execute("SELECT dias, rango, fecha_registro FROM usuarios WHERE telegram_id=?", (telegram_id,))
        usuario_info = c.fetchone()
        dias_registrado = usuario_info[0]
        rango = usuario_info[1]
        fecha = usuario_info[2]

        fecha_registro = datetime.strptime(fecha, '%Y-%m-%d')
        dias_restantes = calcular_dias_restantes(fecha_registro, dias_registrado)
        dias_restantes = int(dias_restantes)

        if dias_restantes <= 0:
            message.reply_text("❌NO TIENES PERMISO...")
        else:
            BIN = message.text[len("/bin"):11].strip()
            if len(BIN) < 6:
                message.reply("𝗕𝗶𝗻 𝗶𝗻𝗰𝗼𝗿𝗿𝗲𝗰𝘁𝗼 𝗳𝗼𝗿𝗺𝗮𝘁𝗼 /bin 𝟰𝟱𝟱𝟲𝟲𝟰")
                return
                
            if not BIN:
                message.reply("𝗕𝗶𝗻 𝗶𝗻𝗳𝗼, 𝘂𝘀𝗲 /𝗯𝗶𝗻 𝟰𝟱𝟱𝟲𝟳𝟰𝟳")
                return
            
            func = get_bin_info(BIN[:6])

                    # Obtén el ID del usuario desde el mensaje
            user_id = int(message.text.split(" ")[1])

            
            message.reply(f"""<b>
𝗩𝗮𝗹𝗶𝗱 𝗕𝗶𝗻           
﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣
𝗕𝗶𝗻 : {BIN[:6]} 
𝗖𝗼𝘂𝗻𝘁𝗿𝘆 :  {func.get("country")} {func.get("flag")}   
𝗕𝗶𝗻 𝗧𝘆𝗽𝗲 : {func.get("type")}          
𝗟𝗲𝘃𝗲𝗹 : {func.get("level")}  
𝗩𝗲𝗻𝗱𝗼𝗿 : {func.get("vendor")}  
𝗕𝗮𝗻𝗸 : {func.get("bank")}  </b> 
﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣
𝗕𝘆 - ↯  @{message.from_user.username} [{rango}] </b>
𝗢𝘄𝗻𝗲𝗿 : @CAT""")
    else:
        message.reply_text("Para acceder a este comando, primero necesitas registrarte usando /register.")
