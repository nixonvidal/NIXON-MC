from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup

# Comando /contacto
@Client.on_message(filters.command("contact"))
def comando_contacto(client, message):
    info_contacto = "Puedes contactar a @Nikobhyn en Telegram:"

    # Crear el botón de contacto
    boton_contacto = InlineKeyboardButton(
        text="Contactar", url="https://t.me/Nikobhyn"
    )

    # Crear el teclado en línea con el botón de contacto
    reply_markup = InlineKeyboardMarkup([[boton_contacto]])

    # Enviar el mensaje con el botón
    message.reply_text(info_contacto, reply_markup=reply_markup)