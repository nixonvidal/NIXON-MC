import platform
from pyrogram import Client, filters

@Client.on_message(filters.command("infosys"))
def infosys_command(client, message):
    user = message.from_user
    chat_id = message.chat.id
    
    system_info = f"""
Sistema Operativo: {platform.system()}
Versión: {platform.version()}
Arquitectura: {platform.architecture()}
Nombre del Nodo: {platform.node()}
Procesador: {platform.processor()}
Python Versión: {platform.python_version()}
    """
    
    message.reply_text(system_info)

# Aquí va tu inicialización del cliente Pyrogram
