import time
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup
import re
from pyrogram.types import CallbackQuery
from datetime import datetime
from Plugins.conexion import connect_to_db
from func_bin import get_bin_info
from func_gen import cc_gen

def verificar_usuario(telegram_id):
    conn = connect_to_db()
    c = conn.cursor()
    c.execute("SELECT * FROM usuarios WHERE telegram_id=?", (telegram_id,))
    result = c.fetchone() is not None
    conn.close()
    return result

def calcular_dias_restantes(fecha_registro, dias):
    tiempo_actual = datetime.now().timestamp()
    segundos_restantes = (fecha_registro.timestamp() + (dias * 24 * 60 * 60)) - tiempo_actual
    dias_restantes = segundos_restantes / (24 * 60 * 60)
    return dias_restantes
bin_prohibido = ["valor1", "valor2", "valor3"]
@Client.on_message(filters.command("gen", prefixes=['.','/','!','?'], case_sensitive=False) & filters.text & ~filters.regex(r'^/gen regen$'))
def registro_command(client, message):
    telegram_id = message.from_user.id
    if verificar_usuario(telegram_id):
        conn = connect_to_db()
        c = conn.cursor()
        c.execute("SELECT dias, rango, fecha_registro FROM usuarios WHERE telegram_id=?", (telegram_id,))
        usuario_info = c.fetchone()
        dias_registrado = usuario_info[0]
        rango = usuario_info[1]
        fecha = usuario_info[2]

        fecha_registro = datetime.strptime(fecha, '%Y-%m-%d')
        dias_restantes = calcular_dias_restantes(fecha_registro, dias_registrado)
        dias_restantes = int(dias_restantes)

        if dias_restantes <= 0:
            message.reply_text("❌NO TIENES PERMISO...")
        else:
            try:
                username = message.from_user.username

                tiempo = time.time()

                global input

                if message.reply_to_message:
                    input = re.findall(r'[0-9x]+', message.reply_to_message.text)
                else:
                    input = re.findall(r'[0-9x]+', message.text)

                user_status = "Unknow"

                if not input:
                    return message.reply(f"<i>❌ formato: <code>/gen 456789</code></i>")

                bin_lasted = message.text[len('/gen '):] 

                user_id = message.from_user.id
                

                if len(input)==1:
                    cc = input[0]
                    mes = 'x'
                    ano = 'x'
                    cvv = 'x'
                elif len(input)==2:
                    cc = input[0]
                    mes = input[1][0:2]
                    ano = 'x'
                    cvv = 'x'
                elif len(input)==3:
                    cc = input[0]
                    mes = input[1][0:2]
                    ano = input[2]
                    cvv = 'x'
                elif len(input)==4:
                    cc = input[0]
                    mes = input[1][0:2]
                    ano = input[2]
                    cvv = input[3]
                else:
                    cc = input[0]
                    mes = input[1][0:2]
                    ano = input[2]
                    cvv = input[3]                

                if len(input[0]) < 6: 
                    return message.reply('<b>Invalid Bin ⚠️</b>', quote=True)
                    
                if cc[0] in bin_prohibido: 
                    return message.reply('<b>Invalid Bin ⚠️</b>', quote=True)    

                cc1, cc2, cc3, cc4, cc5, cc6, cc7, cc8, cc9, cc10 = cc_gen(cc, mes, ano, cvv)

                extra = str(cc) + 'xxxxxxxxxxxxxxxxxxxxxxx'
                if mes == 'x':
                    mes_2 = 'rnd'
                else:
                    mes_2 = mes
                if ano == 'x':
                    ano_2 = 'rnd'
                else:
                    ano_2 = ano
                if cvv == 'x':
                    cvv_2 = 'rnd'
                else:
                    cvv_2 = cvv

                x = get_bin_info(cc[0:6])

                buttons = InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(text='𝗢𝘄𝗻𝗲𝗿', url='https://t.me/D')
                        ],
                        [
                            InlineKeyboardButton(text='REGEN ♻️', callback_data=f'gen_callback') 
                        ]
                    ]
                )

                text =  f"""
𝗜𝗻𝗳𝗼 (`<code>{x.get("vendor")} / {x.get("type")} / {x.get("level")}
{x.get("bank_name")} / {x.get("flag")}</code>`) 
﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣                                                 
<code>{cc1}</code><code>{cc2}</code><code>{cc3}</code><code>{cc4}</code><code>{cc5}</code><code>{cc6}</code><code>{cc7}</code><code>{cc8}</code><code>{cc9}</code><code>{cc10}</code>﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣ 
𝗖𝗵𝗲𝗰𝗸𝗲𝗱 @{username} [CAT]"""

                client.send_message(message.chat.id, text, reply_markup=buttons)

            except Exception as e:
                error_message = f"Ocurrió un error: {str(e)}"
                print(error_message)
                message.reply(error_message)

    else:
        message.reply_text("Para acceder a este comando, primero necesitas registrarte usando /register.")

