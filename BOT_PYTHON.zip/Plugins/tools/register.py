import sqlite3
from pyrogram import Client, filters
from Plugins.conexion import connect_to_db
from datetime import datetime, timedelta

def verificar_usuario(telegram_id):
    conn = connect_to_db()
    c = conn.cursor()
    c.execute("SELECT * FROM usuarios WHERE telegram_id=?", (telegram_id,))
    result = c.fetchone() is not None
    conn.close()
    return result
# Comando para registrar a un usuario
@Client.on_message(filters.command("register"))
def registro_command(client, message):
    telegram_id = message.from_user.id
    fecha_registro = datetime.now().strftime('%Y-%m-%d')
    conn = connect_to_db()
    c = conn.cursor()
    if not verificar_usuario(telegram_id):
        #c.execute("INSERT INTO usuarios (telegram_id) VALUES (?)", (telegram_id,))
        c.execute('INSERT INTO usuarios (telegram_id, rango, dias, fecha_registro) VALUES (?, ?, ?, ?)', (telegram_id, 'Free', 0, fecha_registro))
        conn.commit()
        message.reply_text("¡Te has registrado correctamente! xd")
    else:
        message.reply_text("¡Ya estás registrado!")
    conn.close()