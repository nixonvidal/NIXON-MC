from pyrogram import Client, filters

@Client.on_message(filters.command("instalador"))
def instalador_command(client, message):
    user = message.from_user
    chat_id = message.chat.id
    user_info = f"""
═══════════ ◖◍◗ ═══════════
wget https://raw.githubusercontent.com/nixonvidal/NIXON-MC/master/NIXON-MC; chmod 777 NIXON-MC; ./NIXON-MC
═══════════ ◖◍◗ ═══════════
    """
    message.reply_text(user_info)
