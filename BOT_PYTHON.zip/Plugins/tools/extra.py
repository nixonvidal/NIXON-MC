import time
from datetime import datetime
from pyrogram import Client, filters
from Plugins.conexion import connect_to_db
import random
import requests
def verificar_usuario(telegram_id):
    conn = connect_to_db()
    c = conn.cursor()
    c.execute("SELECT * FROM usuarios WHERE telegram_id=?", (telegram_id,))
    result = c.fetchone() is not None
    conn.close()
    return result

def calcular_dias_restantes(fecha_registro, dias):
    tiempo_actual = datetime.now().timestamp()
    segundos_restantes = (fecha_registro.timestamp() + (dias * 24 * 60 * 60)) - tiempo_actual
    dias_restantes = segundos_restantes / (24 * 60 * 60)
    return dias_restantes
#------COMANDO EXTRA--------#
@Client.on_message(filters.command("extra", ["/", "."]))
def generate_extra(client, message):
    telegram_id = message.from_user.id
    if verificar_usuario(telegram_id):
        conn = connect_to_db()
        c = conn.cursor()
        c.execute("SELECT dias, rango, fecha_registro FROM usuarios WHERE telegram_id=?", (telegram_id,))
        usuario_info = c.fetchone()
        dias_registrado = usuario_info[0]
        rango = usuario_info[1]
        fecha = usuario_info[2]

        fecha_registro = datetime.strptime(fecha, '%Y-%m-%d')
        dias_restantes = calcular_dias_restantes(fecha_registro, dias_registrado)
        dias_restantes = int(dias_restantes)

        if dias_restantes <= 0:
            message.reply_text("❌NO TIENES PERMISO...")
        else:
            tiempoinicio = time.perf_counter()
            inputm = message.text.split(None, 1)
            if len(inputm) != 2 or not inputm[1]:
                # Si el argumento está vacío o no se proporciona, mostrar el formato esperado
                message_text = "<b>𝗨𝘀𝗼 𝗶𝗻𝗰𝗼𝗿𝗿𝗲𝗰𝘁𝗼, 𝗨𝘀𝗮 /extra  𝗹𝗼𝘀 𝗽𝗿𝗶𝗺𝗲𝗿𝗼𝘀 𝟲 𝗱í𝗴𝗶𝘁𝗼𝘀 𝗱𝗲𝗹 𝗕𝗶𝗻.</b>"
                message.reply_text(
                    text=message_text,
                )
                return

            BIN = inputm[1][:6]
            req = requests.get(f"https://bins.antipublic.cc/bins/{BIN}").json()

            try:
                brand = req['brand']
                country = req['country']
                country_name = req['country_name']
                country_flag = req['country_flag']
                country_currencies = req['country_currencies']
                bank = req['bank']
                level = req['level']
                typea = req['type']
            except KeyError:
                message_text = "Lo siento, el BIN no está en mi base de datos."
                message.reply_text(
                    text=message_text
                )
                return

            
            extrapole_results = []
            for _ in range(28):
                random_digits = "".join(random.choice("0123456789") for _ in range(6))
                random_month = random.randint(1, 12)
                random_year = random.randint(2024, 2030)
                extra = f"{BIN}{random_digits}xxxx|{random_month:02d}|{random_year}"
                extrapole_results.append(f"<code>{BIN}{random_digits}xxxx|{random_month:02d}|{random_year}</code>")

            similar_bins = [f"<code>{BIN}{random.choice('0123456789')}{random.choice('0123456789')}{random.choice('0123456789')}{random.choice('0123456789')}</code>" for _ in range(2)]

            tiempofinal = time.perf_counter()

            # Generar la plantilla usando variables
            message_text = f"""
𝘉𝘪𝘯 ⥛ <code> {BIN} </code>» <code>{brand}</code>\n
𝘉𝘢𝘯𝘬 ⥛ <code> {bank}</code>\n
𝘊𝘰𝘶𝘯𝘵𝘳𝘺 ⥛ <code>{country_name}</code><code> {country_flag}</code>
﹣﹣﹣﹣﹣
""" + "\n".join(extrapole_results) + f"""
﹣﹣﹣﹣﹣
𝘉𝘺 ⥛ @{message.from_user.username} [CAT] </b>
𝘖𝘸𝘯𝘦𝘳 ⥛ @CAT"""

            message.reply_text(
                text=message_text,
            )
    else:
        message.reply_text("Para acceder a este comando, primero necesitas registrarte usando /register.")
