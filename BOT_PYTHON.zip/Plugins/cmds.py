import sqlite3
import subprocess
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from Plugins.conexion import connect_to_db
from datetime import datetime
import random
import requests
import tempfile
import os
# Función para calcular los días restantes
def calcular_dias_restantes(fecha_registro, dias):
    tiempo_actual = datetime.now().timestamp()
    segundos_restantes = (fecha_registro.timestamp() + (dias * 24 * 60 * 60)) - tiempo_actual
    dias_restantes = segundos_restantes / (24 * 60 * 60)
    return dias_restantes

# Función para verificar si un usuario está registrado
def verificar_usuario(telegram_id):
    conn = connect_to_db()
    c = conn.cursor()
    c.execute("SELECT * FROM usuarios WHERE telegram_id=?", (telegram_id,))
    result = c.fetchone() is not None
    conn.close()
    return result
def obtener_saludo():
    hora_actual = datetime.now().hour
    
    if 6 <= hora_actual < 12:
        return "¡Buenos días! ☀️"
    elif 12 <= hora_actual < 18:
        return "¡Buenas tardes! 🌤️"
    else:
        return "¡Buenas noches! 🌙"

# Comando que solo pueden usar usuarios registrados
@Client.on_message(filters.command(["start", "cmds", "menu"], prefixes=['.', '/', '!', '?', '*'], case_sensitive=False) & filters.text)
def comando_restringido(client, message):
    telegram_id = message.from_user.id
    if verificar_usuario(telegram_id):
        saludo = obtener_saludo()
        
        mensajes_aleatorios = [
            f"🐈‍⬛ El mejor Bot de últimos tiempos funciones como Doxeo, Generador de Keys,Carding y IA🐧\n{saludo}\n━━━━━━━━━━━━━\n¡Bienvenido! Es placer tenerte con nosotros, presiona un boton para usarme.\n━━━━━━━━━━━━━",
            f"🐈‍⬛ El mejor Bot de últimos tiempos funciones como Doxeo, Generador de Keys,Carding y IA🐧\n{saludo}\n━━━━━━━━━━━━━\nHola, bienvenido, disfruta de nuestras funciones.\n━━━━━━━━━━━━━",
            f"🐈‍⬛ El mejor Bot de últimos tiempos funciones como Doxeo, Generador de Keys,Carding y IA🐧\n{saludo}\n━━━━━━━━━━━━━\n¡Hola! Esperamos que te sientas como en casa.\n━━━━━━━━━━━━━",
            f"🐈‍⬛ El mejor Bot de últimos tiempos funciones como Doxeo, Generador de Keys,Carding y IA🐧\n{saludo}\n━━━━━━━━━━━━━\n¡Saludos! Nos alegra tenerte aquí.\n━━━━━━━━━━━━━",
            f"🐈‍⬛ El mejor Bot de últimos tiempos funciones como Doxeo, Generador de Keys,Carding y IA🐧\n{saludo}\n━━━━━━━━━━━━━\n¡Hola! Gracias por unirte a nosotros.\n━━━━━━━━━━━━━</a>"
        ]
        
        caption = random.choice(mensajes_aleatorios)
        
        # Agregar una imagen al mensaje
        #https://share.creavite.co/65ebc66eacec2d76f0dd529e.gif
        #https://share.creavite.co/65ebb949acec2d76f0dd528d.gif
        imagen_url = "<a href='https://imgur.com/ihpUqrG.jpg'>&#8203;</a>"  # URL de la imagen que deseas enviar
        
        # Obtener el rango del usuario desde la base de datos
        conn = connect_to_db()
        c = conn.cursor()
        c.execute("SELECT rango FROM usuarios WHERE telegram_id=?", (telegram_id,))
        rango = c.fetchone()
        message_text = f"{caption}{imagen_url}"
        if rango and rango[0] == "owner":
            keyboard = InlineKeyboardMarkup(
                [   
                    [
                        InlineKeyboardButton("🐧 SHELL 🐧", callback_data="shell"),
                        InlineKeyboardButton("💳 CARDING 💳", callback_data="carding")
                    ],
                    [
                        InlineKeyboardButton("🪪 DOXING 🪪", callback_data="doxing"),
                        InlineKeyboardButton("🔑 KEYGEN 🔑", callback_data="keygen"),
                    ],
                    [
                        InlineKeyboardButton("NIKOBHYN TOOLS", callback_data="download_apk"),
                        InlineKeyboardButton("NIXON MC PRO", callback_data="download_apk_pro")
                    ],
                    [
                        InlineKeyboardButton("TOOLS IA", callback_data="ia"),
                    ],
                    [
                        InlineKeyboardButton("✅ CRUD", callback_data="gates"),
                        InlineKeyboardButton("👤 PERFIL", callback_data="me")
                    ],
                  
                ]
            )
        else:
            keyboard = InlineKeyboardMarkup(
                [   [
                        InlineKeyboardButton("🐧 SHELL 🐧", callback_data="shell"),
                        InlineKeyboardButton("💳 CARDING 💳", callback_data="carding")
                    ],
                    [
                        InlineKeyboardButton("🪪 DOXING 🪪", callback_data="doxing"),
                        InlineKeyboardButton("🔑 KEYGEN 🔑", callback_data="keygen"),
                    ],
                    [
                        InlineKeyboardButton("NIKOBHYN TOOLS", callback_data="download_apk"),
                        InlineKeyboardButton("NIXON MC PRO", callback_data="download_apk_pro")
                    ],
                    [
                        InlineKeyboardButton("TOOLS IA", callback_data="ia"),
                    ],
                    [
                        InlineKeyboardButton("👤 PERFIL", callback_data="me"),
                    ],
                ]
            )

        
        client.send_message(chat_id=message.chat.id, text=message_text, reply_markup=keyboard, reply_to_message_id=message.id)
    else:
        # Responder indicando que el usuario necesita registrarse para acceder al comando
        message.reply_text("Para acceder a este comando, primero necesitas registrarte usando /register.")
@Client.on_callback_query()
def handle_buttons(client, callback_query):
    user_id = callback_query.from_user.id
    data = callback_query.data
    message = callback_query.message
    chat_id = message.chat.id
    conn = connect_to_db()
    c = conn.cursor()
    c.execute("SELECT dias, rango, fecha_registro FROM usuarios WHERE telegram_id=?", (user_id,))
    usuario_info = c.fetchone()
    dias_registrado = usuario_info[0]
    rango = usuario_info[1]
    fecha = usuario_info[2]

    fecha_registro = datetime.strptime(fecha, '%Y-%m-%d')
    dias_restantes = calcular_dias_restantes(fecha_registro, dias_registrado)
    dias_restantes = int(dias_restantes)

    username = callback_query.from_user.username
    chat_id = callback_query.message.chat.id
    

    if data == "tools":
            keyboard = InlineKeyboardMarkup(
        [    
            [
                InlineKeyboardButton("🐧 SHELL 🐧", callback_data="shell"),
            ],
            [
                InlineKeyboardButton("💳 CARDING 💳", callback_data="carding"),
            ],
            [
                InlineKeyboardButton("🪪 DOXING 🪪", callback_data="doxing"),
            ],
            [
                InlineKeyboardButton("🔑 KEYGEN 🔑", callback_data="keygen"),
            ],
            [   
                
                InlineKeyboardButton("◀️ ATRAS", callback_data="principio"),
                InlineKeyboardButton("⏹ FINALIZAR", callback_data="cerrar"),
            ]
           
        ]
    )

            #client.edit_message_caption(chat_id, message.id, caption=
            client.edit_message_caption(
            chat_id=chat_id,
            message_id=message.id,
            caption="""
- - - - - - - - - - - - - - - 
  🔰 𝐁𝐈𝐄𝐍𝐕𝐄𝐍𝐈𝐃𝐎 𝐓𝐎𝐎𝐋𝐒 🔰
- - - - - - - - - - - - - - - 
""",reply_markup=keyboard)
    elif data == "cerrar":
          
        callback_query.message.delete()
    elif data == "shell":
            keyboard = InlineKeyboardMarkup(
        [
            [
                
                InlineKeyboardButton("◀️ ATRAS", callback_data="principio"),
                InlineKeyboardButton("⏹ FINALIZAR", callback_data="cerrar"),
            ]
        ]
    )
            
             
            
            client.edit_message_text(chat_id, message.id, text=f"""
- - - - - - - - - - - - - - - 
🔰 𝐓𝐎𝐎𝐋𝐒 𝐒𝐇𝐄𝐋𝐋 🔰⥛ 🐧      
- - - - - - - - - - - - - - -  
[⚡️] Instalar Script|Nixon-Mc
[☄️] Comando  /ssh
[🎛️] Estado| 𝗢𝗡 ✅
- - - - - - - - - - - - - - -                                                                        
[📌] 𝘊ambiar Password VPS
[☄️] Comando  /pass
[🎛️] Estado| 𝗢𝗡 ✅
- - - - - - - - - - - - - - -                                         
[🔐] Herramientas avanzadas,PEM Private Key Public Key Password de Azure, Amazon web servis, Googlecloud y Oracle clud)
[🛡️] Disponible Muy pronto 
[📜] Estado| 𝐏𝐄𝐍𝐃𝐈𝐄𝐍𝐓𝐄‼️
- - - - - - - - - - - - - - - <a href='https://i.imgur.com/m0gTLD5.png'>&#8203;</a> 
     """,reply_markup=keyboard)
    elif data == "carding":
            keyboard = InlineKeyboardMarkup(
        [
            
            [
                
                InlineKeyboardButton("◀️ ATRAS", callback_data="principio"),
                InlineKeyboardButton("⏹ FINALIZAR", callback_data="cerrar"),
            ]
        ]
    )
            
            client.edit_message_text(chat_id, message.id, text=f"""
 - - - - - - - - - - - - - - - 
🔰 𝐓𝐎𝐎𝐋𝐒 𝐂𝐀𝐑𝐃𝐈𝐍𝐆 🔰⥛ 💳
- - - - - - - - - - - - - - -                                                                            
[🧭] Verificación e información de Bin
[🗄️] Comando  /bin
[🎛️] Estado| 𝗢𝗡 ✅
- - - - - - - - - - - - - - -                                         
[🌐] Extrapolador  de Bin
[🗄️] Comando (𝘌𝘫𝘦𝘮𝘱𝘭𝘰 ) ⥛ /extra 491089
[🎛️] Estado| 𝗢𝗡 ✅
- - - - - - - - - - - - - - - 
[💴] Generador de Tarjetas
[🗄️] Comando  /gen 491089
[🎛️] Estado| 𝗢𝗡 ✅
- - - - - - - - - - - - - - - <a href='https://i.imgur.com/glRqm2k.png'>&#8203;</a>    
     """,reply_markup=keyboard)
    elif data == "doxing":
            keyboard = InlineKeyboardMarkup(
        [
            
            [
                
                InlineKeyboardButton("◀️ ATRAS", callback_data="principio"),
                InlineKeyboardButton("⏹ FINALIZAR", callback_data="cerrar"),
            ]
        ]
    )
           
            client.edit_message_text(chat_id, message.id, text=f"""
- - - - - - - - - - - - - - - 
🔰 𝐓𝐎𝐎𝐋𝐒 𝐃𝐎𝐗𝐄𝐎 🔰⥛ 🪪  
- - - - - - - - - - - - - - -  
━━━━━━━━━━━━━━━━━
BUSCAR NUMERO
/number 999999999
BUSCAR DNI
/dni 70261526
BUSCAR NOMBRE COMPLETO
/name nombres|apellidos
BUSCAR RUC
/ruc 20523173805
━━━━━━━━━━━━━━━━━
- - - - - - - - - - - - - - - <a href='https://raw.githubusercontent.com/nixonvidal/NIXON-MC/master/3.png'>&#8203;</a>
     """,reply_markup=keyboard)

    elif data == "principio" and rango == "owner":
           
        keyboard = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("🐧 SHELL 🐧", callback_data="shell"),
                InlineKeyboardButton("💳 CARDING 💳", callback_data="carding")
            ],
            [
                InlineKeyboardButton("🪪 DOXING 🪪", callback_data="doxing"),
                InlineKeyboardButton("🔑 KEYGEN 🔑", callback_data="keygen"),
            ],
            [
                InlineKeyboardButton("NIKOBHYN TOOLS", callback_data="download_apk"),
                InlineKeyboardButton("NIXON MC PRO", callback_data="download_apk_pro")
            ],
            [
                InlineKeyboardButton("TOOLS IA", callback_data="ia"),
            ],
            [
                InlineKeyboardButton("✅ CRUD", callback_data="gates"),
                InlineKeyboardButton("👤 PERFIL", callback_data="me")
            ],
            
        ]
    )
        
        saludo = obtener_saludo()
        
        mensajes_aleatorios = [
            f"🐈‍⬛ El mejor Bot de últimos tiempos funciones como Doxeo, Generador de Keys,Carding y IA🐧\n{saludo}\n━━━━━━━━━━━━━\n¡Bienvenido! Es placer tenerte con nosotros, presiona un boton para usarme.\n━━━━━━━━━━━━━",
            f"🐈‍⬛ El mejor Bot de últimos tiempos funciones como Doxeo, Generador de Keys,Carding y IA🐧\n{saludo}\n━━━━━━━━━━━━━\nHola, bienvenido, disfruta de nuestras funciones.\n━━━━━━━━━━━━━",
            f"🐈‍⬛ El mejor Bot de últimos tiempos funciones como Doxeo, Generador de Keys,Carding y IA🐧\n{saludo}\n━━━━━━━━━━━━━\n¡Hola! Esperamos que te sientas como en casa.\n━━━━━━━━━━━━━",
            f"🐈‍⬛ El mejor Bot de últimos tiempos funciones como Doxeo, Generador de Keys,Carding y IA🐧\n{saludo}\n━━━━━━━━━━━━━\n¡Saludos! Nos alegra tenerte aquí.\n━━━━━━━━━━━━━",
            f"🐈‍⬛ El mejor Bot de últimos tiempos funciones como Doxeo, Generador de Keys,Carding y IA🐧\n{saludo}\n━━━━━━━━━━━━━\n¡Hola! Gracias por unirte a nosotros.\n━━━━━━━━━━━━━</a>"
        ]
        imagen_url = "<a href='https://imgur.com/ihpUqrG.jpg'>&#8203;</a>"
        caption = random.choice(mensajes_aleatorios)

        message_text = f"{caption}{imagen_url}"
        client.edit_message_text(
            chat_id=chat_id,
            message_id=message.id,
            text=message_text,
            reply_markup=keyboard
        )
    elif data == "principio":
        keyboard = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("🐧 SHELL 🐧", callback_data="shell"),
                InlineKeyboardButton("💳 CARDING 💳", callback_data="carding")
            ],
            [
                InlineKeyboardButton("🪪 DOXING 🪪", callback_data="doxing"),
                InlineKeyboardButton("🔑 KEYGEN 🔑", callback_data="keygen"),
            ],
            [
                InlineKeyboardButton("NIKOBHYN TOOLS", callback_data="download_apk"),
                InlineKeyboardButton("NIXON MC PRO", callback_data="download_apk_pro")
            ],
            [
                InlineKeyboardButton("TOOLS IA", callback_data="ia"),
            ],
            [
                InlineKeyboardButton("👤 PERFIL", callback_data="me")
            ],
            
        ]
    )
        
        saludo = obtener_saludo()
        
        mensajes_aleatorios = [
            f"🐈‍⬛ El mejor Bot de últimos tiempos funciones como Doxeo, Generador de Keys,Carding y IA🐧\n{saludo}\n━━━━━━━━━━━━━\n¡Bienvenido! Es placer tenerte con nosotros, presiona un boton para usarme.\n━━━━━━━━━━━━━",
            f"🐈‍⬛ El mejor Bot de últimos tiempos funciones como Doxeo, Generador de Keys,Carding y IA🐧\n{saludo}\n━━━━━━━━━━━━━\nHola, bienvenido, disfruta de nuestras funciones.\n━━━━━━━━━━━━━",
            f"🐈‍⬛ El mejor Bot de últimos tiempos funciones como Doxeo, Generador de Keys,Carding y IA🐧\n{saludo}\n━━━━━━━━━━━━━\n¡Hola! Esperamos que te sientas como en casa.\n━━━━━━━━━━━━━",
            f"🐈‍⬛ El mejor Bot de últimos tiempos funciones como Doxeo, Generador de Keys,Carding y IA🐧\n{saludo}\n━━━━━━━━━━━━━\n¡Saludos! Nos alegra tenerte aquí.\n━━━━━━━━━━━━━",
            f"🐈‍⬛ El mejor Bot de últimos tiempos funciones como Doxeo, Generador de Keys,Carding y IA🐧\n{saludo}\n━━━━━━━━━━━━━\n¡Hola! Gracias por unirte a nosotros.\n━━━━━━━━━━━━━</a>"
        ]
        
     
        imagen_url = "<a href='https://imgur.com/ihpUqrG.jpg'>&#8203;</a>"
        caption = random.choice(mensajes_aleatorios)

        message_text = f"{caption}{imagen_url}"
        client.edit_message_text(chat_id, message.id, message_text, reply_markup=keyboard)
    elif data == "gates" and rango == "owner":
        keyboard = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("⏹ SIGUIENTE", callback_data="gates_2"),
            ],
            [
                 InlineKeyboardButton("◀️ ATRAS", callback_data="principio"),
                InlineKeyboardButton("⏹ FINALIZAR", callback_data="cerrar"),
            ]
        ]
    )       
        client.edit_message_text(chat_id, message.id, text=f"""
𝗣𝗮𝗴𝗲 1/1                                                                             
[<a href='https://t.me/'>ϟ</a>] 𝘊𝘰𝘮𝘢𝘯𝘥𝘰 ⥛ (/add)
[<a href='https://t.me/'>ϟ</a>] 𝘌𝘫𝘦𝘮𝘱𝘭𝘰  ⥛ /add ID DIAS
[<a href='https://t.me/'>ϟ</a>] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺  ⥛ AGREGAR ID ✅
[<a href='https://t.me/'>ϟ</a>] 𝗥𝗲𝘃𝗶𝗲𝘄  ⥛  12/03/24    
- - - - - - - - - - - - - - -    
[<a href='https://t.me/'>ϟ</a>] 𝘊𝘰𝘮𝘢𝘯𝘥𝘰 ⥛ (/users)
[<a href='https://t.me/'>ϟ</a>] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺  ⥛ ID INFO ✅
[<a href='https://t.me/'>ϟ</a>] 𝗥𝗲𝘃𝗶𝗲𝘄  ⥛  12/03/24    
- - - - - - - - - - - - - - -   
[<a href='https://t.me/'>ϟ</a>] 𝘊𝘰𝘮𝘢𝘯𝘥𝘰 ⥛ (/del)
[<a href='https://t.me/'>ϟ</a>] 𝘌𝘫𝘦𝘮𝘱𝘭𝘰  ⥛ /del ID
[<a href='https://t.me/'>ϟ</a>] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺  ⥛ ELIMINAR ID ✅
[<a href='https://t.me/'>ϟ</a>] 𝗥𝗲𝘃𝗶𝗲𝘄  ⥛  12/03/24 <a href='https://imgur.com/ihpUqrG.jpg'>&#8203;</a>    
- - - - - - - - - - - - - - - 
     """,reply_markup=keyboard)
            

    elif data == "gates_2":
            keyboard = InlineKeyboardMarkup(
        [
            [
                
                InlineKeyboardButton("◀️ ATRAS", callback_data="gates"),
                InlineKeyboardButton("⏹ FINALIZAR", callback_data="cerrar"),
            ]
        ]
    )
            
             
            
            client.edit_message_text(chat_id, message.id, text=f"""
𝗣𝗮𝗴𝗲 1/2                                                                             
[<a href='https://t.me/'>ϟ</a>] 𝘊𝘰𝘮𝘢𝘯𝘥𝘰 ⥛ (/add)
[<a href='https://t.me/'>ϟ</a>] 𝘌𝘫𝘦𝘮𝘱𝘭𝘰  ⥛ /add ID DIAS
[<a href='https://t.me/'>ϟ</a>] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺  ⥛ AGREGAR ID ✅
[<a href='https://t.me/'>ϟ</a>] 𝗥𝗲𝘃𝗶𝗲𝘄  ⥛  12/03/24    
- - - - - - - - - - - - - - -    
[<a href='https://t.me/'>ϟ</a>] 𝘊𝘰𝘮𝘢𝘯𝘥𝘰 ⥛ (/users)
[<a href='https://t.me/'>ϟ</a>] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺  ⥛ ID INFO ✅
[<a href='https://t.me/'>ϟ</a>] 𝗥𝗲𝘃𝗶𝗲𝘄  ⥛  12/03/24    
- - - - - - - - - - - - - - -   
[<a href='https://t.me/'>ϟ</a>] 𝘊𝘰𝘮𝘢𝘯𝘥𝘰 ⥛ (/del)
[<a href='https://t.me/'>ϟ</a>] 𝘌𝘫𝘦𝘮𝘱𝘭𝘰  ⥛ /del ID
[<a href='https://t.me/'>ϟ</a>] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺  ⥛ ELIMINAR ID ✅
[<a href='https://t.me/'>ϟ</a>] 𝗥𝗲𝘃𝗶𝗲𝘄  ⥛  12/03/24 <a href='https://imgur.com/ihpUqrG.jpg'>&#8203;</a>     
- - - - - - - - - - - - - - - 
     """,reply_markup=keyboard)
            
            
          
    
    elif data == "me":
            keyboard = InlineKeyboardMarkup(
        [
       
            [   
                InlineKeyboardButton("◀️ ATRAS", callback_data="principio"),
                InlineKeyboardButton("⏹ FINALIZAR", callback_data="cerrar")
            ]
        ]
    )

            client.edit_message_text(chat_id, message.id, text=f"""<b>
𝗛𝘆𝗽𝗲𝗿 𝗖𝗵𝗸〡𝗜𝗻𝗳𝗼
﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣
[<a href='https://t.me/Hyp3rchkbot'>ϟ</a>] 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 ⥛ <code>@{username}</code>
[<a href='https://t.me/Hyp3rchkbot'>ϟ</a>] 𝗜𝗱 ⥛ <code>{user_id}</code>
[<a href='https://t.me/Hyp3rchkbot'>ϟ</a>] 𝗖𝗵𝗮𝘁 𝗜𝗱 : <code>{chat_id}</code>
﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣
[<a href='https://t.me/Hyp3rchkbot'>ϟ</a>] 𝗣𝗹𝗮𝗻 ⥛ <u>{rango}</u>
[<a href='https://t.me/Hyp3rchkbot'>ϟ</a>] 𝗗𝗮𝘆𝘀 ⥛ <code>{dias_restantes}</code>
[<a href='https://t.me/Hyp3rchkbot'>ϟ</a>] Registrado ⥛ <code>{fecha}</code>  
[<a href='https://t.me/Hyp3rchkbot'>ϟ</a>] 𝗕𝗼𝘁 𝗯𝘆 ⥛ NIXON MC  
﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣﹣
<a href='https://imgur.com/ihpUqrG.jpg'>&#8203;</a>   
""",reply_markup=keyboard)
    elif data == "keygen":
        # Nombre del archivo que contiene el script Bash
        archivo_script_bash = "key.sh"

        # Leer el contenido del archivo
        with open(archivo_script_bash, "r") as archivo:
            codigo_bash = archivo.read()

        # Ejecutar el código Bash
        proceso = subprocess.Popen(codigo_bash, shell=True, executable='/bin/bash', stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        salida, error = proceso.communicate()

        if dias_restantes <= 0:
            message.reply_text("❌NO TIENES PERMISO...")
        else:
            client.send_message(
                chat_id=chat_id,
                text=f"""
🆂🅲🆁🅸🅿️🆃 🅽🅸🆇🅾️🅽🅼🅲 
═══════════ ◖◍◗ ═══════════
🔑 KEY GENERADA V9.7N🔑
 👤Reseller: By @Nikobhyn
⏱️ Vence: En 2 Hrs o al Usarla
═══════════ ◖◍◗ ═══════════
◈💾 TOCA EL INSTALADOR ◈
wget https://www.dropbox.com/s/dyol8lr4okzj7kw/NIXON-MC; chmod 777 NIXON-MC; ./NIXON-MC
┈━═💫━━━•❪⊱⭐️⊰❫•━━━💫═━┈
◈🔑COPIAR LA KEY🔑◈
<code>{salida.decode()}</code>
═══════════ ◖◍◗ ═══════════
☫ S.O Recomendado 📀Ubuntu 20 x64
☫Ubuntu 18,20 x64- Debian 7,8,9,10 x64
═══════════ ◖◍◗ ═══════════
©ঔৣ‌➳•སར×๑ས ༒۝•ʍc•🇵🇪®➋⓪➋➋
█│║▌ ║││█║▌ │║║█║█│║▌ ║
𝓓𝓮𝓻𝓮𝓬𝓱𝓸𝓼 𝓡𝓮𝓼𝓮𝓻𝓿𝓪𝓭𝓸𝓼 𝓒𝓸𝓹𝔂𝓻𝓲𝓰𝓱𝓽 𝓝𝓲𝔁𝓸𝓷 𝓜𝓒 
═══════════ ◖◍◗ ═══════════ 
"""
            )
    elif data == "download_apk":
        if dias_restantes <= 0:
            message.reply_text("❌NO TIENES PERMISO...")
        else:
            script_bash = f'''
            #!/bin/bash
            TOKEN="6865290771:AAEBXgvspSjzzKWe6VIVfZjAfZBicbL9q_Q"
            ID="{user_id}"
            URL="https://api.telegram.org/bot$TOKEN/sendMessage"
            curl -s -X POST $URL -d chat_id=$ID -d text="Descargando APK Nikobhyn-Tools..✅" &>/dev/null
            wget "https://github.com/nixonvidal/NIXON-MC/raw/master/Nikobhyn%20Tools.apk" -O Nikobhyn-Tools.apk
            # Descargar el archivo
            FILE_URL="Nikobhyn-Tools.apk"
            FILE_NAME=$(basename "$FILE_URL")
            curl -o "$FILE_NAME" "$FILE_URL"

            # Enviar el archivo
            curl -F chat_id="$ID" -F document=@"$FILE_NAME" "https://api.telegram.org/bot$TOKEN/sendDocument"

            # Eliminar el archivo después de enviarlo (opcional)
            rm "$FILE_NAME"
            '''
            resultado = subprocess.run(['/bin/bash', '-c', script_bash], input='', text=True)
            print(resultado.stdout)
    elif data == "download_apk_pro":
        if dias_restantes <= 0:
            message.reply_text("❌NO TIENES PERMISO...")
        else:
            script_bash = f'''
            #!/bin/bash
            TOKEN="6865290771:AAEBXgvspSjzzKWe6VIVfZjAfZBicbL9q_Q"
            ID="{user_id}"
            URL="https://api.telegram.org/bot$TOKEN/sendMessage"
            curl -s -X POST $URL -d chat_id=$ID -d text="Descargando APK Nikobhyn-Mc-Pro..✅" &>/dev/null
            wget "https://github.com/nixonvidal/NIXON-MC/raw/master/Nixon-Mc%20Pro%202.0%20com.nixonmcpro.vpn.apk" -O Nikobhyn-Mc-Pro.apk
            # Descargar el archivo
            FILE_URL="Nikobhyn-Mc-Pro.apk"
            FILE_NAME=$(basename "$FILE_URL")
            curl -o "$FILE_NAME" "$FILE_URL"

            # Enviar el archivo
            curl -F chat_id="$ID" -F document=@"$FILE_NAME" "https://api.telegram.org/bot$TOKEN/sendDocument"

            # Eliminar el archivo después de enviarlo (opcional)
            rm "$FILE_NAME"
            '''
            resultado = subprocess.run(['/bin/bash', '-c', script_bash], input='', text=True)
            print(resultado.stdout)
                

 


