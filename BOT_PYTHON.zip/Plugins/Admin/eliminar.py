from pyrogram import Client, filters
from Plugins.conexion import connect_to_db

@Client.on_message(filters.command("del"))
def eliminar_usuario(client, message):
    # Obtener el telegram_id del usuario que está ejecutando el comando
    telegram_id = message.from_user.id
    username = message.from_user.username
    
    conn = connect_to_db()
    c = conn.cursor()
    
    # Obtener el rango del usuario desde la base de datos
    c.execute("SELECT rango FROM usuarios WHERE telegram_id=?", (telegram_id,))
    rango = c.fetchone()
    
    # Verificar si el usuario tiene el rango de "owner"
    if rango and rango[0] == "owner":
        # Parsear los argumentos del comando
        try:
            _, usuario_a_eliminar = message.text.split(" ", 1)
            usuario_a_eliminar = int(usuario_a_eliminar)
        except ValueError:
            message.reply_text("Formato incorrecto. El formato correcto es: /del telegram_id")
            return
        
        # Eliminar el usuario de la base de datos
        c.execute("DELETE FROM usuarios WHERE telegram_id = ?", (usuario_a_eliminar,))
        conn.commit()
        conn.close()

        message.reply(f"<b>Usuario {usuario_a_eliminar} ha sido eliminado correctamente por {username}.</b> ")
    else:
        message.reply_text("¡No tienes permiso para ejecutar este comando!")
        conn.close()
