import sqlite3
from pyrogram import Client, filters
from Plugins.conexion import connect_to_db

@Client.on_message(filters.command("add"))
def agregar_usuario(client, message):
    # Obtener el telegram_id del usuario que está ejecutando el comando
    telegram_id = message.from_user.id
    username = message.from_user.username
    
    conn = connect_to_db()
    c = conn.cursor()
    
    # Obtener el rango del usuario desde la base de datos
    c.execute("SELECT rango FROM usuarios WHERE telegram_id=?", (telegram_id,))
    rango = c.fetchone()
    
    # Verificar si el usuario tiene el rango de "owner"
    if rango and rango[0] == "owner":
        # Parsear los argumentos del comando
        try:
            _, nuevo_telegram_id, dias = message.text.split(" ", 3)
            nuevo_telegram_id = int(nuevo_telegram_id)
            dias = int(dias)
            nuevo_rango = "Premiun"
        except ValueError:
            message.reply_text("Formato incorrecto. El formato correcto es: /agregar telegram_id dias rango")
            return
        
      
        
        # Insertar el nuevo usuario en la base de datos
        c.execute("UPDATE usuarios SET dias = ?, rango = ?, fecha_registro = date('now') WHERE telegram_id = ?", (dias, nuevo_rango, nuevo_telegram_id))
        conn.commit()
        conn.close()

        # Enviar mensaje directo al usuario con una foto
        photo_path = "garciasportucompra.png"  # Cambia la ruta con la ubicación de tu foto
        client.send_photo(nuevo_telegram_id, photo_path, caption="""𝘉𝘪𝘦𝘯𝘷𝘦𝘯𝘪𝘥𝘰, 𝘨𝘳𝘢𝘤𝘪𝘢𝘴 𝘱𝘰𝘳 𝘵𝘶 𝘤𝘰𝘮𝘱𝘳𝘢 𝘦𝘴𝘱𝘦𝘳𝘰 𝘥𝘪𝘴𝘧𝘳𝘶𝘵𝘦𝘴 𝘦𝘭 𝘣𝘰𝘵.
                           
𝘜𝘯𝘦𝘵𝘦 𝘢𝘭 𝘨𝘳𝘶𝘱𝘰 𝘥𝘦 𝘶𝘴𝘦𝘳𝘴 𝘱𝘳𝘦𝘮𝘪𝘶𝘮 ⥛ https://t.me/
                          
𝘊𝘰𝘥𝘪𝘨𝘰 𝘥𝘦 𝘪𝘯𝘷𝘪𝘵𝘢𝘤𝘪𝘰𝘯 ⥛ `primeracompra`""")

        message.reply(f"<b>Usuario {nuevo_telegram_id} ha sido actualizado a Premium por {dias} días por {username}.</b> ")

        #message.reply_text("¡Usuario agregado correctamente!")
    else:
        message.reply_text("¡No tienes permiso para ejecutar este comando!")
        conn.close()