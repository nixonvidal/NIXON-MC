import sqlite3
from pyrogram import Client, filters
from Plugins.conexion import connect_to_db
# Función para verificar si un usuario está registrado
def verificar_usuario(telegram_id):
    conn = connect_to_db()
    c = conn.cursor()
    c.execute("SELECT * FROM usuarios WHERE telegram_id=?", (telegram_id,))
    result = c.fetchone() is not None
    conn.close()
    return result
@Client.on_message(filters.command("users"))
def mostrar_usuarios(client, message):
    # Obtener el telegram_id del usuario que está ejecutando el comando
    telegram_id = message.from_user.id
    
    # Verificar si el usuario está registrado y tiene el rango de "owner"
    if not verificar_usuario(telegram_id):
        message.reply_text("¡Necesitas estar registrado para usar este comando!")
        return
    
    conn = connect_to_db()
    c = conn.cursor()
        # Obtener el rango del usuario desde la base de datos
    c.execute("SELECT rango FROM usuarios WHERE telegram_id=?", (telegram_id,))
    rango = c.fetchone()
    
    # Verificar si el usuario tiene el rango de "owner"
    if rango and rango[0] == "owner":
        # Obtener todos los usuarios de la base de datos
        c.execute("SELECT telegram_id, dias, rango, fecha_registro FROM usuarios")
        usuarios = c.fetchall()
        
        # Construir el mensaje con la información de los usuarios
        if usuarios:
            message_text = "Usuarios registrados:\n"
            for usuario in usuarios:
                message_text += f"Telegram ID: {usuario[0]}\nDías: {usuario[1]}\nRango: {usuario[2]}\nFecha de registro: {usuario[3]}\n\n"
        else:
            message_text = "No hay usuarios registrados en la base de datos."
        message.reply_text(message_text)
    else:
        message.reply_text("¡No tienes permiso para ejecutar este comando!")
    conn.close()